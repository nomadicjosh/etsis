<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

$string["pluginname"] = "etSIS connector";
$string["enabled"] = "Enable instance verification";
$string["enabled_desc"] =
    "Allow authorized integration service users to read this installation identity. This does not enable SSO or synchronize any records.";
$string["etsis:viewinstance"] = "Read the etSIS installation verification identity";
$string["identityunavailable"] =
    "The installation identity is unavailable. Ask the site administrator to review plugin installation; no new identity has been generated.";
$string["integrationdisabled"] = "etSIS instance verification is disabled.";
$string["etsis:provisionaccounts"] = "Provision reviewed etSIS accounts";
$string["provisioning"] = "Enable reviewed account provisioning";
$string["provisioning_desc"] =
    "Allow the restricted integration service to create accounts. No roles or enrollments are assigned. Requires a reviewed authentication setup.";
$string["ssoauth"] = "Institutional SSO authentication plugin";
$string["ssoauth_desc"] =
    "Installed, enabled external authentication plugin name, such as ldap or saml2. Leave blank to disable SSO provisioning. Configure identity-provider account matching before use.";
$string["passwordemail"] = "Allow Moodle password-setup email";
$string["passwordemail_desc"] =
    "Create manual-authentication accounts and send the native one-use password-reset link. No password is emailed. Verify outbound mail first.";
$string["policyrevision"] = "Authentication policy revision";
$string["policyrevision_desc"] =
    "Change this identifier after significant identity-provider, mail or authentication-policy changes. Earlier reviewed requests will stop for review.";
$string["provisioningunavailable"] =
    "Account provisioning is unavailable. Review service capability, approved installation and authentication setup; retain the original operation for reconciliation.";
$string["provisioningconflict"] =
    "The account request requires identity review. No existing account was adopted.";
$string["privacy:metadata:accounts"] =
    "Account-creation receipts prevent duplicate accounts and repeated setup emails.";
$string["privacy:metadata:userid"] = "The Moodle account created for the operation.";
$string["privacy:metadata:operation"] = "Opaque creation operation reference.";
$string["privacy:metadata:requesthash"] = "Digest of the reviewed request, used to refuse changed retries.";
$string["privacy:metadata:signinstatus"] = "Whether SSO or password-setup email completed or needs review.";
$string["privacy:metadata:timecreated"] = "Receipt creation time.";

$string["launch"] = "Enable direct etSIS launch";
$string["launch_desc"] =
    "Allow linked accounts to sign in from etSIS. Requires a dedicated deployment secret. Linked sessions stop when the originating etSIS sign-in ends or cannot be verified.";
$string["sisurl"] = "Trusted etSIS HTTPS base URL";
$string["sisurl_desc"] =
    "Exact canonical HTTPS address of the etSIS institution. Browser launch Origin must match this address.";
$string["launchunavailable"] =
    "Moodle launch is unavailable. Return to etSIS and try again, or contact your institution.";
$string["linkedsessionended"] =
    "Your linked campus sign-in ended or could not be verified. Return to etSIS and sign in again.";
$string["launchaccountswitch"] = "Sign out of the current Moodle account, then open Moodle from etSIS again.";
$string["privacy:metadata:sessionchannel"] =
    "Direct launch sends a one-use credential or a linked-session reference and Moodle user ID to the institution’s etSIS server to verify access. The Moodle session stores the reference and original expiry; it does not store the etSIS cookie.";
$string["privacy:metadata:grant"] = "Opaque reference to the originating campus sign-in.";
