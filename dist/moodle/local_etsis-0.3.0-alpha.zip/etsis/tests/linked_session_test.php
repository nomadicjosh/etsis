<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis;
use local_etsis\local\{instance_identity, linked_session, session_channel};
defined("MOODLE_INTERNAL") || die();
/** Run only in a separately configured Moodle PHPUnit database. Never uses the live server channel. */
final class linked_session_test extends \advanced_testcase
{
    private function setup_channel(array $reply): session_channel
    {
        global $CFG;
        $this->resetAfterTest();
        $CFG->local_etsis_launch_secret = str_repeat("c", 64);
        instance_identity::initialize();
        set_config("enabled", 1, "local_etsis");
        set_config("launch", 1, "local_etsis");
        set_config("sisurl", "https://campus.example.invalid", "local_etsis");
        return new session_channel(static function (string $url, string $body, array $headers) use (
            $reply,
        ): array {
            $values = [];
            foreach ($headers as $header) {
                [$key, $value] = explode(": ", $header, 2);
                $values[$key] = $value;
            }
            $response = json_encode($reply, JSON_THROW_ON_ERROR);
            $signature = hash_hmac(
                "sha256",
                "etsis-moodle/v1\nresponse\n" .
                    $values["X-Etsis-Time"] .
                    "\n" .
                    $values["X-Etsis-Nonce"] .
                    "\n" .
                    $response,
                hex2bin(str_repeat("c", 64)),
            );
            return [200, $response, $signature];
        });
    }
    public function test_signed_validation_preserves_original_deadline(): void
    {
        $grant = [
            "active" => true,
            "grant_id" => "01KAWQ0DWGP8PYVM92HQ7Y43GB",
            "moodle_user_id" => "123",
            "expires_at" => time() + 300,
        ];
        $channel = $this->setup_channel($grant);
        linked_session::validate($grant, 123, $channel);
        $this->assertTrue(session_channel::permits_origin("https://campus.example.invalid"));
        $this->assertFalse(session_channel::permits_origin("https://attacker.example.invalid"));
        $this->assertFalse(session_channel::permits_origin("null"));
    }
    public function test_native_login_uses_exact_account_without_role_assignment(): void
    {
        global $USER, $SESSION, $DB;
        $this->setUser(null);
        $this->redirectEmails();
        $user = $this->getDataGenerator()->create_user([
            "email" => "fictional@example.invalid",
            "auth" => "manual",
        ]);
        $grant = [
            "active" => true,
            "grant_id" => "01KAWQ0DWGP8PYVM92HQ7Y43GB",
            "moodle_user_id" => (string) $user->id,
            "expires_at" => time() + 300,
        ];
        $channel = $this->setup_channel($grant);
        linked_session::launch(str_repeat("e", 64), "https://campus.example.invalid", $channel);
        $this->assertSame((int) $user->id, (int) $USER->id);
        $this->assertSame($grant["expires_at"], $SESSION->local_etsis_launch["expires_at"]);
        $this->assertSame(0, $DB->count_records("role_assignments", ["userid" => $user->id]));
    }
    public function test_revoked_grant_refuses_access(): void
    {
        $channel = $this->setup_channel(["active" => false]);
        $this->expectException(\moodle_exception::class);
        linked_session::validate(
            [
                "grant_id" => "01KAWQ0DWGP8PYVM92HQ7Y43GB",
                "moodle_user_id" => "123",
                "expires_at" => time() + 300,
            ],
            123,
            $channel,
        );
    }
}
