<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

$string["pluginname"] = "etSIS connector";
$string["enabled"] = "Enable instance verification";
$string["enabled_desc"] =
    "Allow authorized integration service users to read this installation identity. This does not enable SSO or synchronize any records.";
$string["etsis:viewinstance"] = "Read the etSIS installation verification identity";
$string["identityunavailable"] =
    "The installation identity is unavailable. Ask the site administrator to review plugin installation; no new identity has been generated.";
$string["integrationdisabled"] = "etSIS instance verification is disabled.";
$string["etsis:provisionaccounts"] = "Provision reviewed etSIS accounts";
$string["provisioning"] = "Enable reviewed account provisioning";
$string["provisioning_desc"] =
    "Allow the restricted integration service to create accounts. No roles or enrollments are assigned. Requires a reviewed authentication setup.";
$string["ssoauth"] = "Institutional SSO authentication plugin";
$string["ssoauth_desc"] =
    "Installed, enabled external authentication plugin name, such as ldap or saml2. Leave blank to disable SSO provisioning. Configure identity-provider account matching before use.";
$string["passwordemail"] = "Allow Moodle password-setup email";
$string["passwordemail_desc"] =
    "Create manual-authentication accounts and send the native one-use password-reset link. No password is emailed. Verify outbound mail first.";
$string["policyrevision"] = "Authentication policy revision";
$string["policyrevision_desc"] =
    "Change this identifier after significant identity-provider, mail or authentication-policy changes. Earlier reviewed requests will stop for review.";
$string["provisioningunavailable"] =
    "Account provisioning is unavailable. Review service capability, approved installation and authentication setup; retain the original operation for reconciliation.";
$string["provisioningconflict"] =
    "The account request requires identity review. No existing account was adopted.";
$string["privacy:metadata:accounts"] =
    "Account-creation receipts prevent duplicate accounts and repeated setup emails.";
$string["privacy:metadata:userid"] = "The Moodle account created for the operation.";
$string["privacy:metadata:operation"] = "Opaque creation operation reference.";
$string["privacy:metadata:requesthash"] = "Digest of the reviewed request, used to refuse changed retries.";
$string["privacy:metadata:signinstatus"] = "Whether SSO or password-setup email completed or needs review.";
$string["privacy:metadata:timecreated"] = "Receipt creation time.";
