<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

$plugin->component = "local_etsis";
$plugin->version = 2026111200;
$plugin->requires = 2024100700; // Moodle 4.5; deployment acceptance required on each supported branch.
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = "0.2.0-alpha";
