<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage("local_etsis", get_string("pluginname", "local_etsis"));
    $ADMIN->add("localplugins", $settings);
    if ($ADMIN->fulltree) {
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/provisioning",
                get_string("provisioning", "local_etsis"),
                get_string("provisioning_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/ssoauth",
                get_string("ssoauth", "local_etsis"),
                get_string("ssoauth_desc", "local_etsis"),
                "",
                PARAM_ALPHANUMEXT,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/passwordemail",
                get_string("passwordemail", "local_etsis"),
                get_string("passwordemail_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/policyrevision",
                get_string("policyrevision", "local_etsis"),
                get_string("policyrevision_desc", "local_etsis"),
                "1",
                PARAM_ALPHANUMEXT,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/enabled",
                get_string("enabled", "local_etsis"),
                get_string("enabled_desc", "local_etsis"),
                0,
            ),
        );
    }
}
