<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** One creation decision, one native course; never adopt or overwrite an existing course. */
final class course_provisioner
{
    public static function execute(string $instance, string $operation, string $payload): array
    {
        global $DB, $CFG;
        require_once $CFG->dirroot . "/course/lib.php";
        require_once $CFG->libdir . "/enrollib.php";
        $context = \context_system::instance();
        \core_external\external_api::validate_context($context);
        require_capability("local/etsis:syncsections", $context);
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            (int) get_config("local_etsis", "coursecreation") !== 1 ||
            !hash_equals(hash("sha256", instance_identity::read()), $instance) ||
            !preg_match('/^[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $operation) ||
            strlen($payload) > 4096
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $p = json_decode($payload, true, 4, JSON_THROW_ON_ERROR);
        if (
            !is_array($p) ||
            count($p) !== 5 ||
            !is_string($p["shortname"] ?? null) ||
            !preg_match('/^etsis-[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $p["shortname"]) ||
            !is_string($p["fullname"] ?? null) ||
            $p["fullname"] === "" ||
            \core_text::strlen($p["fullname"]) > 254 ||
            clean_param($p["fullname"], PARAM_NOTAGS) !== $p["fullname"] ||
            !is_int($p["startdate"] ?? null) ||
            !is_int($p["enddate"] ?? null) ||
            $p["startdate"] < 1 ||
            $p["enddate"] <= $p["startdate"]
        ) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        if (
            !is_string($p["category"] ?? null) ||
            !preg_match('/^[1-9][0-9]{0,18}$/D', $p["category"]) ||
            (string) (int) $p["category"] !== $p["category"]
        ) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        $category = (int) $p["category"];
        unset($p["category"]);
        $categoryRecord = $DB->get_record("course_categories", ["id" => $category]);
        if ($category < 1 || !$categoryRecord) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $categorycontext = \context_coursecat::instance($category);
        \core_external\external_api::validate_context($categorycontext);
        require_capability("moodle/course:create", $categorycontext);
        $manual = enrol_get_plugin("manual");
        if (!$manual || !enrol_is_enabled("manual")) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $digest = hash("sha256", $operation);
        $hash = hash("sha256", json_encode($p, JSON_THROW_ON_ERROR) . ":" . $category);
        $lock = \core\lock\lock_config::get_lock_factory("local_etsis")->get_lock("course:" . $digest, 5);
        if (!$lock) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        try {
            $receipt = $DB->get_record("local_etsis_courses", ["operation" => $digest]);
            if ($receipt) {
                if (
                    !hash_equals($receipt->requesthash, $hash) ||
                    !$receipt->courseid ||
                    !$DB->record_exists("course", [
                        "id" => $receipt->courseid,
                        "shortname" => $p["shortname"],
                    ])
                ) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
                $courseid = $receipt->courseid;
            } else {
                if ($DB->record_exists("course", ["shortname" => $p["shortname"]])) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
                $transaction = $DB->start_delegated_transaction();
                try {
                    $course = create_course(
                        (object) ($p + [
                            "category" => $category,
                            "visible" => (int) ($categoryRecord->visible ?? 1),
                            "format" => get_config("moodlecourse", "format") ?: "topics",
                            "summary" => "",
                            "summaryformat" => FORMAT_PLAIN,
                        ]),
                    );
                    if (
                        !$DB->record_exists("enrol", [
                            "courseid" => $course->id,
                            "enrol" => "manual",
                            "status" => ENROL_INSTANCE_ENABLED,
                        ])
                    ) {
                        $manual->add_instance($course, ["status" => ENROL_INSTANCE_ENABLED]);
                    }
                    $courseid = $course->id;
                    $DB->insert_record(
                        "local_etsis_courses",
                        (object) ["operation" => $digest, "requesthash" => $hash, "courseid" => $courseid],
                    );
                    $transaction->allow_commit();
                } catch (\Throwable $error) {
                    $transaction->rollback($error);
                }
            }
            return [
                "protocol" => 1,
                "instance_hash" => $instance,
                "operation" => $operation,
                "course_id" => (string) $courseid,
            ];
        } finally {
            $lock->release();
        }
    }
}
