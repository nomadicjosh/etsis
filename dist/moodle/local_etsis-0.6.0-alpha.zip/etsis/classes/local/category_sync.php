<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** Reference categories only. No enrollment, grade or course moves. */
final class category_sync
{
    public static function execute(string $instance, string $payload): array
    {
        global $DB;
        $context = \context_system::instance();
        \core_external\external_api::validate_context($context);
        require_capability("local/etsis:syncsections", $context);
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            !hash_equals(hash("sha256", instance_identity::read()), $instance) ||
            strlen($payload) > 4096
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $p = json_decode($payload, true, 4, JSON_THROW_ON_ERROR);
        if (
            !is_array($p) ||
            count($p) !== 6 ||
            !in_array($p["source"] ?? null, ["subjects", "departments"], true) ||
            !is_string($p["reference_id"] ?? null) ||
            !preg_match('/^[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $p["reference_id"]) ||
            !is_int($p["version"] ?? null) ||
            $p["version"] < 1 ||
            $p["version"] > 2147483646 ||
            !is_string($p["category_id"] ?? null) ||
            !preg_match('/^(?:0|[1-9][0-9]{0,18})$/D', $p["category_id"]) ||
            (string) (int) $p["category_id"] !== $p["category_id"]
        ) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        foreach (["code" => 80, "title" => 191] as $key => $max) {
            if (
                !is_string($p[$key] ?? null) ||
                trim($p[$key]) === "" ||
                \core_text::strlen($p[$key]) > $max ||
                preg_match('/[\x00-\x1F\x7F]/', $p[$key]) ||
                clean_param($p[$key], PARAM_NOTAGS) !== $p[$key]
            ) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
        }
        $key = hash("sha256", $instance . ":" . $p["source"] . ":" . $p["reference_id"]);
        $hash = hash("sha256", $payload);
        $lock = \core\lock\lock_config::get_lock_factory("local_etsis")->get_lock("category:" . $key, 5);
        if (!$lock) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        try {
            $old = $DB->get_record("local_etsis_categories", ["sourcehash" => $key]);
            if (
                $old &&
                (!$old->categoryid ||
                    !$DB->record_exists("course_categories", ["id" => $old->categoryid]) ||
                    ($p["category_id"] !== "0" && (int) $p["category_id"] !== (int) $old->categoryid))
            ) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
            $target = $old ? (int) $old->categoryid : (int) $p["category_id"];
            $targetcontext = $target ? \context_coursecat::instance($target) : $context;
            \core_external\external_api::validate_context($targetcontext);
            require_capability("moodle/category:manage", $targetcontext);
            if ($old && (int) $old->version > $p["version"]) {
                return self::result($instance, $p, $old, "superseded");
            }
            if ($old && (int) $old->version === $p["version"]) {
                if (!hash_equals($old->requesthash, $hash)) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
                return self::result($instance, $p, $old, "unchanged");
            }
            $idnumber = "etsis-" . $p["source"] . "-" . $p["reference_id"];
            $name = \core_text::substr($p["code"] . " · " . $p["title"], 0, 254);
            $tx = $DB->start_delegated_transaction();
            try {
                if (!$old && !$target) {
                    if ($DB->record_exists("course_categories", ["idnumber" => $idnumber])) {
                        throw new \moodle_exception("provisioningconflict", "local_etsis");
                    }
                    $category = \core_course_category::create([
                        "name" => $name,
                        "idnumber" => $idnumber,
                        "parent" => 0,
                        "visible" => 1,
                    ]);
                    $target = (int) $category->id;
                    $owned = 1;
                } else {
                    $category = \core_course_category::get($target, MUST_EXIST, true);
                    $owned = $old ? (int) $old->owned : 0;
                    if ($owned) {
                        if (
                            !$DB->record_exists("course_categories", [
                                "id" => $target,
                                "idnumber" => $idnumber,
                            ])
                        ) {
                            throw new \moodle_exception("provisioningconflict", "local_etsis");
                        }
                        $category->update(["name" => $name]);
                    }
                }
                $row = (object) [
                    "sourcehash" => $key,
                    "categoryid" => $target,
                    "owned" => $owned,
                    "version" => $p["version"],
                    "requesthash" => $hash,
                ];
                if ($old) {
                    $row->id = $old->id;
                    $DB->update_record("local_etsis_categories", $row);
                } else {
                    $DB->insert_record("local_etsis_categories", $row);
                }
                $tx->allow_commit();
            } catch (\Throwable $e) {
                $tx->rollback($e);
            }
            return self::result($instance, $p, $row, "synchronized");
        } finally {
            $lock->release();
        }
    }
    private static function result(string $instance, array $p, object $row, string $status): array
    {
        return [
            "protocol" => 1,
            "instance_hash" => $instance,
            "reference_id" => $p["reference_id"],
            "version" => $p["version"],
            "category_id" => (string) $row->categoryid,
            "owned" => (bool) $row->owned,
            "status" => $status,
        ];
    }
}
