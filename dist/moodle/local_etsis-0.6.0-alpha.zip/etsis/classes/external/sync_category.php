<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\external;
use core_external\{external_api, external_function_parameters, external_single_structure, external_value};
defined("MOODLE_INTERNAL") || die();
final class sync_category extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation"),
            "payload" => new external_value(
                PARAM_RAW,
                "Subject or department identity and reviewed category intent",
            ),
        ]);
    }
    public static function execute(string $instance_hash, string $payload): array
    {
        $p = self::validate_parameters(self::execute_parameters(), compact("instance_hash", "payload"));
        try {
            return \local_etsis\local\category_sync::execute($p["instance_hash"], $p["payload"]);
        } catch (\Throwable) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation"),
            "reference_id" => new external_value(PARAM_ALPHANUM, "Stable SIS reference"),
            "version" => new external_value(PARAM_INT, "Synchronization fence"),
            "category_id" => new external_value(PARAM_ALPHANUM, "Retained Moodle category"),
            "owned" => new external_value(PARAM_BOOL, "Whether the connector created this category"),
            "status" => new external_value(PARAM_ALPHANUMEXT, "Fixed synchronization status"),
        ]);
    }
}
