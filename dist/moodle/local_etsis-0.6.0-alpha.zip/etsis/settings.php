<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage("local_etsis", get_string("pluginname", "local_etsis"));
    $ADMIN->add("localplugins", $settings);
    if ($ADMIN->fulltree) {
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/launch",
                get_string("launch", "local_etsis"),
                get_string("launch_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/sisurl",
                get_string("sisurl", "local_etsis"),
                get_string("sisurl_desc", "local_etsis"),
                "",
                PARAM_URL,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/provisioning",
                get_string("provisioning", "local_etsis"),
                get_string("provisioning_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/ssoauth",
                get_string("ssoauth", "local_etsis"),
                get_string("ssoauth_desc", "local_etsis"),
                "",
                PARAM_ALPHANUMEXT,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/passwordemail",
                get_string("passwordemail", "local_etsis"),
                get_string("passwordemail_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/policyrevision",
                get_string("policyrevision", "local_etsis"),
                get_string("policyrevision_desc", "local_etsis"),
                "1",
                PARAM_ALPHANUMEXT,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/rostersync",
                get_string("rostersync", "local_etsis"),
                get_string("rostersync_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/coursecreation",
                get_string("coursecreation", "local_etsis"),
                get_string("coursecreation_desc", "local_etsis"),
                0,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/studentrole",
                get_string("studentrole", "local_etsis"),
                get_string("studentrole_desc", "local_etsis"),
                "",
                PARAM_INT,
            ),
        );
        $settings->add(
            new admin_setting_configtext(
                "local_etsis/teacherrole",
                get_string("teacherrole", "local_etsis"),
                get_string("teacherrole_desc", "local_etsis"),
                "",
                PARAM_INT,
            ),
        );
        $settings->add(
            new admin_setting_configcheckbox(
                "local_etsis/enabled",
                get_string("enabled", "local_etsis"),
                get_string("enabled_desc", "local_etsis"),
                0,
            ),
        );
    }
}
