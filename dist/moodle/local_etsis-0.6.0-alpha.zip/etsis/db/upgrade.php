<?php
// SPDX-License-Identifier: GPL-3.0-or-later
defined("MOODLE_INTERNAL") || die();
function xmldb_local_etsis_upgrade(int $oldversion): bool
{
    global $DB;
    if ($oldversion < 2026111200) {
        $manager = $DB->get_manager();
        $file = new xmldb_file(__DIR__ . "/install.xml");
        $file->loadXMLStructure();
        $table = $file->getStructure()->getTable("local_etsis_accounts");
        if (!$manager->table_exists($table)) {
            $manager->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026111200, "local", "etsis");
    }
    if ($oldversion < 2026111204) {
        $manager = $DB->get_manager();
        $file = new xmldb_file(__DIR__ . "/install.xml");
        $file->loadXMLStructure();
        $table = $file->getStructure()->getTable("local_etsis_members");
        if (!$manager->table_exists($table)) {
            $manager->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026111204, "local", "etsis");
    }
    if ($oldversion < 2026111205) {
        $manager = $DB->get_manager();
        $file = new xmldb_file(__DIR__ . "/install.xml");
        $file->loadXMLStructure();
        $table = $file->getStructure()->getTable("local_etsis_courses");
        if (!$manager->table_exists($table)) {
            $manager->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026111205, "local", "etsis");
    }
    if ($oldversion < 2026111206) {
        $manager = $DB->get_manager();
        $file = new xmldb_file(__DIR__ . "/install.xml");
        $file->loadXMLStructure();
        $table = $file->getStructure()->getTable("local_etsis_categories");
        if (!$manager->table_exists($table)) {
            $manager->create_table($table);
        }
        upgrade_plugin_savepoint(true, 2026111206, "local", "etsis");
    }
    return true;
}
