<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis;
defined("MOODLE_INTERNAL") || die();
/** Native acceptance; dedicated Moodle PHPUnit database only. */
final class category_sync_test extends \advanced_testcase
{
    public function test_owned_rename_stale_fence_and_explicit_link_without_renaming(): void
    {
        global $DB;
        $this->resetAfterTest();
        $this->setAdminUser();
        set_config("enabled", 1, "local_etsis");
        set_config("instanceid", str_repeat("a", 32), "local_etsis");
        $instance = hash("sha256", str_repeat("a", 32));
        $p = [
            "source" => "subjects",
            "reference_id" => "01KAT5HZXS0000000000000001",
            "code" => "MATH",
            "title" => "Mathematics",
            "version" => 1,
            "category_id" => "0",
        ];
        $first = \local_etsis\local\category_sync::execute($instance, json_encode($p, JSON_THROW_ON_ERROR));
        self::assertTrue($first["owned"]);
        $p["title"] = "Mathematical Sciences";
        $p["version"] = 2;
        $second = \local_etsis\local\category_sync::execute($instance, json_encode($p, JSON_THROW_ON_ERROR));
        self::assertSame($first["category_id"], $second["category_id"]);
        self::assertSame(
            "MATH · Mathematical Sciences",
            $DB->get_field("course_categories", "name", ["id" => (int) $first["category_id"]], MUST_EXIST),
        );
        $p["version"] = 1;
        $p["title"] = "Mathematics";
        self::assertSame(
            "superseded",
            \local_etsis\local\category_sync::execute($instance, json_encode($p, JSON_THROW_ON_ERROR))[
                "status"
            ],
        );
        $existing = $this->getDataGenerator()->create_category(["name" => "Existing institutional category"]);
        $p["reference_id"] = "01KAT5HZXS0000000000000002";
        $p["category_id"] = (string) $existing->id;
        $linked = \local_etsis\local\category_sync::execute($instance, json_encode($p, JSON_THROW_ON_ERROR));
        self::assertFalse($linked["owned"]);
        self::assertSame(
            "Existing institutional category",
            $DB->get_field("course_categories", "name", ["id" => $existing->id], MUST_EXIST),
        );
    }
}
