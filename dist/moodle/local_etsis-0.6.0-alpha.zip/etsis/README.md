# etSIS connector for Moodle

Component: `local_etsis` · Release: **0.6.0-alpha** · License: **GPL-3.0-or-later**

This optional connector verifies the installation and supports reviewed, retry-safe account creation. It offers institutional SSO accounts or Moodle password-setup emails, subject to explicit institutional configuration. Optional section synchronization reconciles student/instructor course access with separate enablement. Course creation is a separate opt-in; gradebook import remains pending, and launch requires its own enablement. Separately configured direct launch establishes a restricted sign-in trust with etSIS. SIS workflows remain available without it.

## Install or upgrade

The plugin declares Moodle **4.5 or later**. This alpha requires acceptance testing on each deployed Moodle branch, including the institution's authentication and mail configuration.

1. Download `local_etsis-0.6.0-alpha.zip` and verify its SHA-256 against the independently obtained checksum.
2. As a Moodle administrator, use **Site administration → Plugins → Install plugins**, or replace `local/etsis` in the Moodle code root and visit **Notifications**. Some installations use a `public/` code root.
3. Upgrade from 0.1.0 retains the original installation identity and creates the account-receipt table. Do not uninstall/reinstall to upgrade. Back up the installation through institutional procedures first.
4. Verification, account provisioning, section synchronization, direct launch and password-email mode default off; no capability, token or role is granted automatically. Installation/upgrade creates no user accounts or email.

## Enable installation verification

1. Under **Plugins → Local plugins → etSIS connector**, enable instance verification.
2. Enable Moodle web services and REST. Grant a dedicated integration account **local/etsis:viewinstance** at system context through a narrowly scoped role; avoid administrator tokens.
3. Enable the restricted predefined **etSIS instance verification** service, authorize that account, and issue its service token. Its functions are `core_webservice_get_site_info` and `local_etsis_get_instance_info`.
4. Supply the canonical HTTPS URL and token through protected etSIS deployment settings. Never include a token in command arguments, URLs, screenshots or browser storage. Set `SIS_MOODLE_ENABLED=true`.
5. Run `ddev codex sis:moodle:instance`, compare the fingerprint, then approve the installation in the etSIS Moodle administration screen.

## Enable reviewed account provisioning

Keep provisioning disabled until authentication, mail and fictional-account acceptance tests have passed.

1. Enable **reviewed account provisioning** in connector settings. Select the supported sign-in modes:
   - For SSO, enter the installed, enabled external authentication plugin name, such as `ldap` or `saml2`. Configure and verify its identity-provider matching independently. Provisioning creates only the Moodle-side record; it never changes an identity-provider password or creates an identity-provider account. Some plugins require additional issuer/link configuration and may not support this provisioning arrangement.
   - For password setup, enable **Moodle password-setup email** and verify manual authentication, password recovery and outbound mail. A native one-use reset link is emailed; no generated password is sent.
2. Give the integration account **local/etsis:provisionaccounts** and **moodle/user:create**, in addition to its verification grant. Enable **etSIS account provisioning**, authorize the account and issue a token for this service. The old identity-only token cannot call the new functions. The new service includes site information, instance verification, `local_etsis_get_account_policy`, `local_etsis_provision_account` and the targeted existing-user lookup used for manual linking. Existing custom services may add these functions after review. Targeted lookup still needs its native Moodle view capabilities.
3. Store the new service token securely in etSIS. Grant authorized staff `sis:moodle:create-person`, `sis:person:manage` and applicable local-account management authority.
4. Enable `SIS_MOODLE_ACCOUNT_REQUESTS_ENABLED=true` for reviewed intake. Enable `SIS_MOODLE_PROVISIONING_ENABLED=true` separately when the worker may perform approved external effects.
5. In etSIS, open a person, select **Create a Moodle account**, review and confirm the account and sign-in choice. Run `ddev codex sis:moodle:provision` with the configured application runtime, or schedule it once per minute through an institution-managed scheduler. Each invocation processes at most one request; it does not run continuously.
6. Refresh the person workspace to see queued, processing, completed or review-required status and its retained Moodle link. Account creation requires no separate manual-link step.

Both sides must remain enabled. Changing SSO plugin or password-email enablement changes the reviewed policy fingerprint. Increment **Authentication policy revision** after significant changes to underlying identity-provider or mail arrangements. Requests reviewed against a different policy stop for reconciliation; they are not silently reinterpreted.

## Retry and privacy boundaries

The Moodle account and its receipt commit in one transaction. An opaque creation-operation digest is unique; a retry with identical reviewed attributes returns the original user ID. Existing usernames/emails are refused rather than adopted. Changed retries, erased receipts, missing/deleted/suspended accounts or installation/policy mismatches stop processing. No SIS password, institutional ID, course history, administrative reason, credential or profile copy is saved in the receipt. Receipt IDs use Moodle's native numeric schema; the external creation-operation identifier is an etSIS ULID.

Email delivery cannot be made atomic with a database commit. A committed attempt marker prevents blind repeated sending. If the process stops around delivery, the account remains retained and the status requires review; use Moodle's normal password-recovery workflow for that existing account. `email_sent` means Moodle's mail API accepted delivery, not proof that the recipient received it.

The privacy provider supports receipt discovery, export and erasure. Erasure removes the user reference, request digest, sign-in result and timestamp, retaining an opaque operation-digest denial tombstone so an old retry cannot recreate an account. Core Moodle owns the account and password-reset records. Apply institutional retention review; the connector does not establish legal compliance by itself.

## Identity, disabling and recovery

Initial installation alone generates the instance identity; reads and upgrades never rotate it. Missing identity blocks operations. Restore the same identifier when recovering the same installation. A database clone carries that identity and receipts: keep clones disconnected. Never remove receipts, change operation IDs or uninstall/reinstall to resolve an uncertain creation outcome.

Disable connector provisioning, its service/token or the etSIS provisioning flag to stop new attempts. Disable etSIS intake separately to prevent new requests. Existing receipts, person links and academic facts remain intact. A `review_required` request is not automatically reset: reconcile the original operation and account before any administrative correction. A dedicated request-correction workflow remains a later stage.

## Developer checks

Native Moodle tests are in `tests/instance_identity_test.php`, `tests/account_provisioner_test.php` `tests/linked_session_test.php` and `tests/roster_sync_test.php` and `tests/course_provisioner_test.php`. Run only in Moodle's separately configured PHPUnit database. etSIS also provides gateway, worker, private-route, browser and isolated connector-contract tests plus reproducible ZIP tests. The contract sandbox uses fictional SQLite, authentication and mail adapters; it does not establish native Moodle or institution-specific SSO/mail acceptance. No real mailbox should be used as a test fixture.

Sources: [external functions](https://moodledev.io/docs/5.3/apis/subsystems/external/functions), [Lock API](https://moodledev.io/docs/5.3/apis/core/lock), [Privacy API](https://moodledev.io/docs/5.3/apis/subsystems/privacy).

## Optional direct etSIS launch

This release adds direct launch separately from provisioning. Upgrade in place; do not uninstall or rotate the installation identity. Enable the connector and **direct etSIS launch**, and set the exact trusted etSIS HTTPS base URL. Supply the dedicated 64-character lowercase hexadecimal secret through protected deployment configuration as `$CFG->local_etsis_launch_secret`; supply the same value as `SIS_MOODLE_LAUNCH_SECRET` in etSIS and enable `SIS_MOODLE_LAUNCH_ENABLED`. Never reuse a REST token or native cookie key. Optionally set `$CFG->local_etsis_launch_ca_file` for a trusted private CA bundle.

The etSIS portal derives the signed-in owner's approved link. The POST-only receiver requires the exact trusted browser Origin and exchanges a 60-second one-use credential through a signed server channel. It logs in the exact active Moodle account using native APIs, without granting roles or bypassing MFA. Site administrators are refused; a different logged-in Moodle account must sign out first.

Marked Moodle sessions retain the original etSIS expiry. A modern after-config hook validates each marked PHP request, including cookie-authenticated AJAX and private files, against etSIS. No cached positive validation is used. Connection/total timeouts are one/three seconds; responses are bounded, TLS is verified and outages stop access. Source logout/reauthentication/credential change ends linked access on its next check. Moodle activity never extends the source deadline. Moodle may time out earlier. Moodle-only logout currently ends only Moodle access. Other native Moodle sessions are unaffected. Removal of the connector removes its enforcement; deploy it as part of the authentication security boundary.

See `docs/moodle-direct-launch.md` in the etSIS distribution for setup and acceptance. Run the supplied `tests/linked_session_test.php` only in a dedicated Moodle PHPUnit database. Verify native upgrade, login hooks/MFA, session backend, TLS, expiry/logout, AJAX/files and concurrent load with fictional accounts before enabling real use. The isolated etSIS sandbox is not proof of native Moodle acceptance. No shared native cookie, institutional OIDC provider or bidirectional logout is included.

Version 0.3.1-alpha clarifies the site-administrator refusal and renders launch failures locally with Moodle sign-in and campus return actions. It does not change administrator-account eligibility. Generic failures still omit credentials, account details and upstream errors.

## Inspect original account-creation receipts

Version 0.3.2-alpha adds `local_etsis_get_account_receipt` to the restricted provisioning service. Add that function explicitly if your token uses a custom service. It requires `local/etsis:provisionaccounts` and `local/etsis:viewinstance`, an enabled connector and the exact installation, operation and original request digest. Account processing and authentication modes can remain disabled; this is a read-only inspection of an earlier fact.

The function returns a retained eligible account's ID and recorded sign-in setup result, a restricted outcome without an account ID, or no observed receipt. A missing receipt does not prove that an operation failed: it could still be running. Pending/attempting mail markers are reported as requiring review without updating them or sending email. The function creates no account, role, reset link or receipt and grants no site-administrator access. No profile attributes are required in the inspection request or returned in its response.

Use the normal plugin upgrade and preserve the existing installation identity and receipts. There is no schema change or automatic service/provisioning enablement. Follow the etSIS **Check original Moodle operation** workflow; inspection does not attach recovered accounts or requeue exhausted requests. Native Moodle tests are supplied but must run in a separately configured PHPUnit database, never the institution's application database.


## Optional section access synchronization

Version 0.4.0-alpha adds **etSIS section synchronization**, a restricted disabled service combining the existing account functions with `local_etsis_get_roster_policy` and `local_etsis_sync_roster_member`. Upgrade in place; the additive `local_etsis_members` receipt table preserves all existing account receipts and installation identity.

Enable **etSIS section access synchronization** separately and configure existing student and teacher/editingteacher course-role IDs. Grant the integration account `local/etsis:syncsections`, the required course-level manual enrollment capabilities, `moodle/role:assign` and authority to assign those specific roles. Enable a manual enrollment instance in each mapped course. An existing service token must use the new service or explicitly include the new functions. Provisioning remains separately controlled.

The SIS maps one published section to one existing Moodle course and sends one minimized desired membership at a time. The connector manages only enrollments it originally created and suspends access on removal; it never unenrolls or deletes learning records. Existing manual enrollments remain externally managed. Monotonic receipts reject stale or changed retries; ordinary retries reuse the native enrollment. Privacy erasure removes the user reference and retains a denial tombstone. Disablement stops future synchronization without erasing receipts or learning history.

Follow the consolidated **Section course mapping and background access** instructions in `docs/optional-moodle-integration.md` in etSIS for actor grants, access windows, worker scheduling, fixed setup statuses and remaining acceptance. First-use account eligibility and course creation are available below; gradebook import remains future work. Run fictional acceptance with the institution's native Moodle enrollment/role configuration before enabling real use.


## Publication-triggered course creation (0.5.0-alpha)

Upgrade in place. This release adds `local_etsis_provision_course` to **etSIS section synchronization** and adds the `local_etsis_courses` original-operation receipt table. Existing installation, account and membership receipts remain intact. Custom services need the new function; an existing predefined-service token remains attached to its service after upgrade. Verify the updated function list.

Enable **section course creation**, choose **Subjects** or **Departments** in the etSIS Moodle panel and grant the integration user `moodle/category:manage` for reference-category creation plus `moodle/course:create` in the resulting categories in addition to `local/etsis:syncsections` at system context. The native manual-enrollment plugin must be enabled. Creation retains a unique `etsis-<section ULID>` shortname, reviewed display title and instructional dates, and ensures an enabled manual-enrollment instance. Creation respects the category visibility and configured default course format. Participants gain course access when the separate roster policy grants it; instructors can prepare it before the student access window.

Repeated requests return the original course without overwriting later instructor edits. Existing shortname conflicts, changed requests/category, missing original courses and lost authority are refused. The native course, manual-enrollment instance and creation receipt commit atomically. No existing course is adopted, deleted or silently renamed; use the SIS manual-link workflow for pre-existing courses.

Automatic first-use account creation remains controlled by etSIS institutional flags, current roles and section eligibility. It reuses this connector's existing account operation receipts and optional password-setup email or external SSO mode. No SIS password or administrator authority is copied. Existing Moodle identity conflicts require explicit staff linking. Follow the combined etSIS setup guide; native acceptance must use a dedicated PHPUnit database and fictional accounts.


## SIS-controlled subject/department categories (0.6.0-alpha)

The single **Moodle course category ID** setting has been removed. In etSIS **Moodle integration → Organize Moodle courses**, choose **Subjects** or **Departments**. The existing background worker discovers active references, creates matching top-level categories and updates connector-created names. Existing Moodle categories can be explicitly linked by an authorized staff member; their native names remain unchanged. Categories are identified by stable SIS reference IDs, never by matching display names.

The restricted section-sync service gains `local_etsis_sync_category`. Upgrading adds `local_etsis_categories`, retaining ownership and monotonic request fences; account, course and roster receipts and the installation identity remain intact. The integration user needs `local/etsis:syncsections` at system context, `moodle/category:manage` at system context to create top-level categories (or in the chosen existing category for explicit linking/management), and `moodle/course:create` in destinations. Tokens using custom services need the new function. Do not uninstall to upgrade.

Course creation now requires its explicit mapped category ID from etSIS. It never reads the old global category setting. Current creation receipt hashing continues to bind the course attributes and actual destination, preserving retained receipts. No existing course is moved. Later policy changes affect new publication reviews; accepted requests retain their original reference routing. Native privacy exports remain limited to person-related receipts; reference-category receipts contain no student/profile data.

Native `tests/category_sync_test.php` and the etSIS gateway, route, worker, browser and isolated connector tests cover ownership, renaming, explicit links, idempotency, stale requests and rollback. Run native acceptance only in a dedicated Moodle PHPUnit database. See the consolidated etSIS integration guide for policy setup, publication prerequisites and remaining acceptance.
