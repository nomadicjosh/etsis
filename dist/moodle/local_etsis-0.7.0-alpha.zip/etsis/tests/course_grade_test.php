<?php

// SPDX-License-Identifier: GPL-3.0-or-later

declare(strict_types=1);

// Moodle requires its direct-access guard and native autoload/API names.
// phpcs:disable PSR1.Files.SideEffects
// phpcs:disable Squiz.Classes.ValidClassName.NotCamelCaps
// phpcs:disable PSR1.Methods.CamelCapsMethodName.NotCamelCaps

namespace local_etsis;

use local_etsis\local\course_grade;
use local_etsis\local\instance_identity;

defined('MOODLE_INTERNAL') || die();

/** Native acceptance tests: run only with Moodle's dedicated PHPUnit database. */
final class course_grade_test extends \advanced_testcase
{
    public function testReleasedCourseTotalIsReadWithoutChangingGradeRows(): void
    {
        global $DB, $CFG;
        $this->resetAfterTest();
        $this->setAdminUser();
        require_once $CFG->libdir . '/gradelib.php';
        set_config('enabled', 1, 'local_etsis');
        set_config('gradeexport', 1, 'local_etsis');
        instance_identity::initialize();
        $course = $this->getDataGenerator()->create_course();
        $student = $this->getDataGenerator()->create_user();
        $this->getDataGenerator()->enrol_user($student->id, $course->id);
        $item = \grade_item::fetch_course_item($course->id);
        $item->needsupdate = 0;
        $item->hidden = 0;
        $item->update();
        $grade = \grade_grade::fetch(['itemid' => $item->id, 'userid' => $student->id]);
        if (!$grade) {
            $grade = new \grade_grade(['itemid' => $item->id, 'userid' => $student->id]);
            $grade->insert();
        }
        $grade->finalgrade = 91.25;
        $grade->hidden = 0;
        $grade->update();
        $before = $DB->get_record('grade_grades', ['id' => $grade->id]);
        $result = course_grade::read(hash('sha256', instance_identity::read()), $course->id, $student->id);
        $this->assertSame('available', $result['grade']['state']);
        $this->assertSame('91.25000', $result['grade']['grade']);
        $this->assertEquals($before, $DB->get_record('grade_grades', ['id' => $grade->id]));
        $DB->set_field('grade_grades', 'hidden', 1, ['id' => $grade->id]);
        $hidden = course_grade::read(hash('sha256', instance_identity::read()), $course->id, $student->id);
        $this->assertSame('hidden', $hidden['grade']['state']);
        $this->assertNull($hidden['grade']['grade']);
        $this->assertNull($hidden['grade']['item_id']);
    }
}
