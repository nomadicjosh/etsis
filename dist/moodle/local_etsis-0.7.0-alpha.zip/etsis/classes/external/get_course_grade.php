<?php

// SPDX-License-Identifier: GPL-3.0-or-later

declare(strict_types=1);

// Moodle requires its direct-access guard and native autoload/API names.
// phpcs:disable PSR1.Files.SideEffects
// phpcs:disable Squiz.Classes.ValidClassName.NotCamelCaps
// phpcs:disable PSR1.Methods.CamelCapsMethodName.NotCamelCaps

namespace local_etsis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

defined('MOODLE_INTERNAL') || die();

final class get_course_grade extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            'instance_hash' => new external_value(PARAM_ALPHANUM, 'Approved installation'),
            'course_id' => new external_value(PARAM_INT, 'Explicit linked course'),
            'user_id' => new external_value(PARAM_INT, 'Explicit linked user'),
        ]);
    }

    public static function execute(string $instance_hash, int $course_id, int $user_id): array
    {
        $p = self::validate_parameters(self::execute_parameters(), [
            'instance_hash' => $instance_hash, 'course_id' => $course_id, 'user_id' => $user_id,
        ]);
        try {
            return \local_etsis\local\course_grade::read($p['instance_hash'], $p['course_id'], $p['user_id']);
        } catch (\Throwable) {
            throw new \moodle_exception('provisioningunavailable', 'local_etsis');
        }
    }

    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            'protocol' => new external_value(PARAM_INT, 'Protocol'),
            'instance_hash' => new external_value(PARAM_ALPHANUM, 'Installation hash'),
            'course_id' => new external_value(PARAM_INT, 'Linked course'),
            'user_id' => new external_value(PARAM_INT, 'Linked user'),
            'grade' => new external_single_structure([
                'state' => new external_value(PARAM_ALPHA, 'Availability'),
                'item_id' => new external_value(PARAM_RAW, 'Course grade item', VALUE_REQUIRED, null, NULL_ALLOWED),
                'grade' => new external_value(PARAM_RAW, 'Raw decimal', VALUE_REQUIRED, null, NULL_ALLOWED),
                'minimum' => new external_value(PARAM_RAW, 'Raw minimum', VALUE_REQUIRED, null, NULL_ALLOWED),
                'maximum' => new external_value(PARAM_RAW, 'Raw maximum', VALUE_REQUIRED, null, NULL_ALLOWED),
                'revision' => new external_value(PARAM_ALPHANUM, 'Source revision'),
            ]),
        ]);
    }
}
