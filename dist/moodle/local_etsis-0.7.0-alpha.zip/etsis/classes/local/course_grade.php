<?php

// SPDX-License-Identifier: GPL-3.0-or-later

declare(strict_types=1);

// Moodle requires its direct-access guard and native autoload/API names.
// phpcs:disable PSR1.Files.SideEffects
// phpcs:disable Squiz.Classes.ValidClassName.NotCamelCaps
// phpcs:disable PSR1.Methods.CamelCapsMethodName.NotCamelCaps

namespace local_etsis\local;

defined('MOODLE_INTERNAL') || die();

/** Bounded, read-only course-total export. Never regrade or create a missing grade item. */
final class course_grade
{
    public static function read(string $instancehash, int $courseid, int $userid): array
    {
        global $DB, $CFG;
        require_once $CFG->libdir . '/enrollib.php';
        $system = \context_system::instance();
        \core_external\external_api::validate_context($system);
        require_capability('local/etsis:exportgrades', $system);
        if (
            (int) get_config('local_etsis', 'enabled') !== 1 ||
            (int) get_config('local_etsis', 'gradeexport') !== 1 ||
            !hash_equals(hash('sha256', instance_identity::read()), $instancehash) ||
            $courseid <= SITEID || $userid < 1
        ) {
            throw new \moodle_exception('provisioningunavailable', 'local_etsis');
        }
        $context = \context_course::instance($courseid);
        \core_external\external_api::validate_context($context);
        require_capability('moodle/grade:viewall', $context);
        $user = $DB->get_record('user', ['id' => $userid], 'id,deleted,suspended');
        if (!$user || $user->deleted || $user->suspended || !is_enrolled($context, $userid, '', false)) {
            throw new \moodle_exception('provisioningunavailable', 'local_etsis');
        }
        $item = $DB->get_record(
            'grade_items',
            ['courseid' => $courseid, 'itemtype' => 'course'],
            'id,gradetype,grademin,grademax,hidden,needsupdate,timemodified'
        );
        $grade = $item ? $DB->get_record(
            'grade_grades',
            ['itemid' => $item->id, 'userid' => $userid],
            'id,itemid,finalgrade,hidden,timemodified'
        ) : false;
        $hidden = static fn(int $value): bool => $value === 1 || $value > time();
        $state = 'ungraded';
        if ($item && ($hidden((int) $item->hidden) || ($grade && $hidden((int) $grade->hidden)))) {
            $state = 'hidden';
        } elseif (
            $item && ((int) $item->gradetype !== GRADE_TYPE_VALUE || $item->needsupdate ||
            (float) $item->grademax <= (float) $item->grademin)
        ) {
            $state = 'unsupported';
        } elseif ($item && $grade && $grade->finalgrade !== null) {
            $state = 'available';
        }
        $available = $state === 'available';
        $decimal = static fn(mixed $value): string => number_format((float) $value, 5, '.', '');
        $facts = ['state' => $state, 'item_id' => $available ? (string) $item->id : null,
            'grade' => $available ? $decimal($grade->finalgrade) : null,
            'minimum' => $available ? $decimal($item->grademin) : null,
            'maximum' => $available ? $decimal($item->grademax) : null];
        $facts['revision'] = hash('sha256', json_encode([$facts, $item->id ?? null,
            $item->timemodified ?? null, $grade->id ?? null, $grade->timemodified ?? null], JSON_THROW_ON_ERROR));
        return ['protocol' => 1, 'instance_hash' => $instancehash,
            'course_id' => $courseid, 'user_id' => $userid, 'grade' => $facts];
    }
}
