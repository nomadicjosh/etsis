<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis;
defined("MOODLE_INTERNAL") || die();
/** Native course creation acceptance; dedicated Moodle PHPUnit database only. */
final class course_provisioner_test extends \advanced_testcase
{
    public function test_retry_returns_original_course_and_does_not_replace_edited_content(): void
    {
        global $DB;
        $this->resetAfterTest();
        $this->setAdminUser();
        $category = $this->getDataGenerator()->create_category();
        set_config("enabled", 1, "local_etsis");
        set_config("coursecreation", 1, "local_etsis");
        set_config("coursecategory", $category->id, "local_etsis");
        set_config("instanceid", str_repeat("a", 32), "local_etsis");
        $p = [
            "shortname" => "etsis-01KAT5HZXS0000000000000001",
            "fullname" => "Fictional course",
            "startdate" => 1790000000,
            "enddate" => 1795000000,
        ];
        $instance = hash("sha256", str_repeat("a", 32));
        $operation = "01KAT5HZXS0000000000000002";
        $first = \local_etsis\local\course_provisioner::execute(
            $instance,
            $operation,
            json_encode($p, JSON_THROW_ON_ERROR),
        );
        $DB->set_field("course", "fullname", "Instructor edited title", ["id" => (int) $first["course_id"]]);
        self::assertSame(
            $first,
            \local_etsis\local\course_provisioner::execute(
                $instance,
                $operation,
                json_encode($p, JSON_THROW_ON_ERROR),
            ),
        );
        self::assertSame(
            "Instructor edited title",
            $DB->get_field("course", "fullname", ["id" => (int) $first["course_id"]], MUST_EXIST),
        );
        self::assertTrue(
            $DB->record_exists("enrol", [
                "courseid" => (int) $first["course_id"],
                "enrol" => "manual",
                "status" => ENROL_INSTANCE_ENABLED,
            ]),
        );
        self::assertSame(1, $DB->count_records("local_etsis_courses"));
        $p["fullname"] = "Changed creation request";
        $this->expectException(\moodle_exception::class);
        \local_etsis\local\course_provisioner::execute(
            $instance,
            $operation,
            json_encode($p, JSON_THROW_ON_ERROR),
        );
    }
}
