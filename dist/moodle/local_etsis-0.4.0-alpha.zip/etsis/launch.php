<?php
// SPDX-License-Identifier: GPL-3.0-or-later
// Remove the credential before Moodle bootstrap/error handlers inspect request parameters.
$ticket = $_POST["ticket"] ?? null;
unset($_POST["ticket"], $_REQUEST["ticket"]);
require_once __DIR__ . "/../../config.php";
header("Cache-Control: private, no-store, max-age=0");
header("Referrer-Policy: no-referrer");
header("Content-Security-Policy: default-src 'self'; frame-ancestors 'none'; base-uri 'self'");
try {
    if (
        ($_SERVER["REQUEST_METHOD"] ?? "") !== "POST" ||
        ($_SERVER["QUERY_STRING"] ?? "") !== "" ||
        !is_string($ticket)
    ) {
        throw new moodle_exception("launchunavailable", "local_etsis");
    }
    \local_etsis\local\linked_session::launch($ticket, (string) ($_SERVER["HTTP_ORIGIN"] ?? ""));
} catch (Throwable $error) {
    unset($ticket);
    // Never render raw exception messages, traces, request bodies or generated remote documentation links.
    \local_etsis\local\launch_error::display(
        $error instanceof moodle_exception ? $error->errorcode : "launchunavailable",
    );
    exit();
}
unset($ticket);
redirect(new moodle_url("/my/"));
