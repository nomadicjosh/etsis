<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis;
defined("MOODLE_INTERNAL") || die();
/** Native enrollment checks. Run only against Moodle's dedicated PHPUnit database. */
final class roster_sync_test extends \advanced_testcase
{
    private function scenario(): array
    {
        global $DB;
        $this->resetAfterTest();
        $this->setAdminUser();
        set_config("enabled", 1, "local_etsis");
        set_config("rostersync", 1, "local_etsis");
        set_config("instanceid", str_repeat("a", 32), "local_etsis");
        set_config(
            "studentrole",
            $DB->get_field("role", "id", ["archetype" => "student"], MUST_EXIST),
            "local_etsis",
        );
        set_config(
            "teacherrole",
            $DB->get_field("role", "id", ["archetype" => "editingteacher"], MUST_EXIST),
            "local_etsis",
        );
        $course = $this->getDataGenerator()->create_course();
        $user = $this->getDataGenerator()->create_user();
        $p = [
            "section" => "01KAT5HZXS0000000000000001",
            "course" => (string) $course->id,
            "person" => "01KAT5HZXS0000000000000002",
            "user" => (string) $user->id,
            "version" => 1,
            "student" => true,
            "instructor" => false,
        ];
        $instance = hash("sha256", str_repeat("a", 32));
        return [$p, $instance, \local_etsis\local\roster_sync::policy($instance)["policy_hash"]];
    }
    public function test_retries_suspend_without_unenrollment_and_stale_requests_cannot_restore_access(): void
    {
        global $DB;
        [$p, $instance, $policy] = $this->scenario();
        $send = static fn(array $payload): array => \local_etsis\local\roster_sync::execute(
            $instance,
            $policy,
            json_encode($payload, JSON_THROW_ON_ERROR),
        );
        self::assertSame("synchronized", $send($p)["status"]);
        self::assertSame("unchanged", $send($p)["status"]);
        $receipt = $DB->get_record("local_etsis_members", [], "*", MUST_EXIST);
        self::assertSame(
            1,
            $DB->count_records("user_enrolments", [
                "enrolid" => $receipt->enrolid,
                "userid" => (int) $p["user"],
            ]),
        );
        $suspend = $p;
        $suspend["version"] = 2;
        $suspend["student"] = false;
        $send($suspend);
        self::assertSame(
            ENROL_USER_SUSPENDED,
            (int) $DB->get_field(
                "user_enrolments",
                "status",
                ["enrolid" => $receipt->enrolid, "userid" => (int) $p["user"]],
                MUST_EXIST,
            ),
        );
        self::assertSame("superseded", $send($p)["status"]);
        self::assertTrue($DB->record_exists("user", ["id" => (int) $p["user"]]));
        self::assertTrue($DB->record_exists("course", ["id" => (int) $p["course"]]));
    }
    public function test_existing_manual_enrollment_is_never_adopted(): void
    {
        global $DB;
        [$p, $instance, $policy] = $this->scenario();
        $this->getDataGenerator()->enrol_user((int) $p["user"], (int) $p["course"]);
        self::assertSame(
            "externally_managed",
            \local_etsis\local\roster_sync::execute($instance, $policy, json_encode($p, JSON_THROW_ON_ERROR))[
                "status"
            ],
        );
        self::assertFalse($DB->record_exists("local_etsis_members", []));
        self::assertTrue(
            $DB->record_exists("user_enrolments", [
                "userid" => (int) $p["user"],
                "status" => ENROL_USER_ACTIVE,
            ]),
        );
    }
}
