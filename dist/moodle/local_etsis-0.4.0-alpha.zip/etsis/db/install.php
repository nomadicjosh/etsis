<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

/** Initial installation only. Reads and upgrades must never rotate the instance identity. */
function xmldb_local_etsis_install(): void
{
    \local_etsis\local\instance_identity::initialize();
    set_config("enabled", 0, "local_etsis");
}
