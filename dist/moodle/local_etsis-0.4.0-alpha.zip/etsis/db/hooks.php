<?php
// SPDX-License-Identifier: GPL-3.0-or-later
defined("MOODLE_INTERNAL") || die();
$callbacks = [
    [
        "hook" => \core\hook\after_config::class,
        "callback" => [\local_etsis\local\linked_session::class, "after_config"],
        "priority" => 1000,
    ],
];
