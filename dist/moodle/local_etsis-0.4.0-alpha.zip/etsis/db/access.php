<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

$capabilities = [
    "local/etsis:syncsections" => [
        "captype" => "write",
        "contextlevel" => CONTEXT_SYSTEM,
        "archetypes" => [],
        "riskbitmask" => RISK_PERSONAL,
    ],
    "local/etsis:provisionaccounts" => [
        "captype" => "write",
        "contextlevel" => CONTEXT_SYSTEM,
        "archetypes" => [],
        "riskbitmask" => RISK_PERSONAL,
    ],
    "local/etsis:viewinstance" => [
        "captype" => "read",
        "contextlevel" => CONTEXT_SYSTEM,
        "archetypes" => [],
    ],
];
