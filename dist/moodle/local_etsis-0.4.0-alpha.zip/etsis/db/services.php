<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined("MOODLE_INTERNAL") || die();

$functions = [
    "local_etsis_get_roster_policy" => [
        "classname" => 'local_etsis\\external\\get_roster_policy',
        "methodname" => "execute",
        "description" => "Read the enabled course-role policy.",
        "type" => "read",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:syncsections",
    ],
    "local_etsis_sync_roster_member" => [
        "classname" => 'local_etsis\\external\\sync_roster_member',
        "methodname" => "execute",
        "description" =>
            "Reconcile one institution-managed course membership without deleting learning records.",
        "type" => "write",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:syncsections",
    ],
    "local_etsis_get_account_receipt" => [
        "classname" => 'local_etsis\\external\\get_account_receipt',
        "methodname" => "execute",
        "description" =>
            "Inspect one exact existing creation receipt without creating accounts or sending email.",
        "type" => "read",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:provisionaccounts,local/etsis:viewinstance",
    ],
    "local_etsis_get_account_policy" => [
        "classname" => 'local_etsis\\external\\get_account_policy',
        "methodname" => "execute",
        "description" => "Review enabled authentication workflows without personal data.",
        "type" => "read",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:provisionaccounts,moodle/user:create",
    ],
    "local_etsis_provision_account" => [
        "classname" => 'local_etsis\\external\\provision_account',
        "methodname" => "execute",
        "description" => "Create one reviewed account with a durable idempotency receipt.",
        "type" => "write",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:provisionaccounts,moodle/user:create",
    ],
    "local_etsis_get_instance_info" => [
        "classname" => 'local_etsis\external\get_instance_info',
        "methodname" => "execute",
        "description" => "Read the installation identity without personal or academic data.",
        "type" => "read",
        "ajax" => false,
        "loginrequired" => true,
        "capabilities" => "local/etsis:viewinstance",
    ],
];
$services = [
    "etSIS section synchronization" => [
        "functions" => [
            "core_webservice_get_site_info",
            "local_etsis_get_instance_info",
            "core_course_get_courses_by_field",
            "local_etsis_get_roster_policy",
            "local_etsis_sync_roster_member",
            "local_etsis_get_account_policy",
            "local_etsis_provision_account",
            "local_etsis_get_account_receipt",
            "core_user_get_users_by_field",
        ],
        "restrictedusers" => 1,
        "enabled" => 0,
        "shortname" => "local_etsis_sections",
    ],
    "etSIS account provisioning" => [
        "functions" => [
            "core_webservice_get_site_info",
            "local_etsis_get_instance_info",
            "local_etsis_get_account_policy",
            "local_etsis_provision_account",
            "local_etsis_get_account_receipt",
            "core_user_get_users_by_field",
        ],
        "restrictedusers" => 1,
        "enabled" => 0,
        "shortname" => "local_etsis_accounts",
    ],
    "etSIS instance verification" => [
        "functions" => ["core_webservice_get_site_info", "local_etsis_get_instance_info"],
        "restrictedusers" => 1,
        "enabled" => 0,
        "shortname" => "local_etsis_identity",
    ],
];
