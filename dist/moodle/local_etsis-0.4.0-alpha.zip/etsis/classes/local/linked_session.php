<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** Only sessions established through the opt-in etSIS launcher carry this marker. */
final class linked_session
{
    public static function after_config(\core\hook\after_config $hook): void
    {
        global $SESSION, $USER;
        if ((defined("CLI_SCRIPT") && CLI_SCRIPT) || !isset($SESSION->local_etsis_launch)) {
            return;
        }
        header("Cache-Control: private, no-store, max-age=0");
        // A fresh launch may replace an expired grant; the receiver independently requires trusted POST Origin.
        $receiver = realpath(__DIR__ . "/../../launch.php");
        if ($receiver !== false && realpath($_SERVER["SCRIPT_FILENAME"] ?? "") === $receiver) {
            return;
        }
        try {
            self::validate($SESSION->local_etsis_launch, (int) ($USER->id ?? 0), new session_channel());
        } catch (\Throwable) {
            \core\session\manager::terminate_current();
            throw new \moodle_exception("linkedsessionended", "local_etsis");
        }
    }
    public static function validate(
        #[\SensitiveParameter] mixed $marker,
        int $userid,
        session_channel $channel,
    ): void {
        if (
            !is_array($marker) ||
            !is_string($marker["grant_id"] ?? null) ||
            !preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $marker["grant_id"]) ||
            !is_int($marker["expires_at"] ?? null) ||
            $marker["expires_at"] <= time() ||
            ($marker["moodle_user_id"] ?? null) !== (string) $userid
        ) {
            throw new \moodle_exception("linkedsessionended", "local_etsis");
        }
        $result = $channel->send([
            "op" => "check",
            "grant_id" => $marker["grant_id"],
            "moodle_user_id" => (string) $userid,
        ]);
        if (
            !hash_equals($marker["grant_id"], $result["grant_id"]) ||
            $result["moodle_user_id"] !== (string) $userid ||
            $result["expires_at"] !== $marker["expires_at"]
        ) {
            throw new \moodle_exception("linkedsessionended", "local_etsis");
        }
    }
    public static function launch(
        #[\SensitiveParameter] string $ticket,
        string $origin,
        ?session_channel $channel = null,
    ): void {
        global $CFG, $USER, $SESSION;
        require_once $CFG->libdir . "/authlib.php";
        if (!session_channel::permits_origin($origin) || preg_match('/^[a-f0-9]{64}$/D', $ticket) !== 1) {
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
        $result = ($channel ?? new session_channel())->send(["op" => "exchange", "ticket" => $ticket]);
        $user = get_complete_user_data("id", (int) $result["moodle_user_id"]);
        if (
            !$user ||
            !empty($user->deleted) ||
            !empty($user->suspended) ||
            empty($user->confirmed) ||
            isguestuser($user) ||
            $user->auth === "nologin" ||
            !is_enabled_auth($user->auth)
        ) {
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
        if (is_siteadmin($user)) {
            throw new \moodle_exception("launchsiteadmin", "local_etsis");
        }
        // Avoid carrying another account's session state into this login.
        if (isloggedin() && !isguestuser() && (int) $USER->id !== (int) $user->id) {
            throw new \moodle_exception("launchaccountswitch", "local_etsis");
        }
        $SESSION->local_etsis_launch = [
            "grant_id" => $result["grant_id"],
            "moodle_user_id" => $result["moodle_user_id"],
            "expires_at" => $result["expires_at"],
        ];
        try {
            complete_user_login($user);
        } catch (\Throwable) {
            \core\session\manager::terminate_current();
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
        // No auth/MFA bypass flags. Native require_login checks still apply at /my/.
    }
}
