<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** Desired course access only. Never delete an account, course, enrollment or learning record. */
final class roster_sync
{
    public static function policy(string $instancehash): array
    {
        global $DB;
        $context = \context_system::instance();
        \core_external\external_api::validate_context($context);
        require_capability("local/etsis:syncsections", $context);
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            (int) get_config("local_etsis", "rostersync") !== 1 ||
            !hash_equals(hash("sha256", instance_identity::read()), $instancehash)
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $student = (string) get_config("local_etsis", "studentrole");
        $teacher = (string) get_config("local_etsis", "teacherrole");
        if (
            !preg_match('/^[1-9][0-9]{0,18}$/D', $student) ||
            !preg_match('/^[1-9][0-9]{0,18}$/D', $teacher) ||
            $student === $teacher ||
            (string) (int) $student !== $student ||
            (string) (int) $teacher !== $teacher
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $s = $DB->get_record("role", ["id" => (int) $student]);
        $t = $DB->get_record("role", ["id" => (int) $teacher]);
        if (
            !$s ||
            !$t ||
            $s->archetype !== "student" ||
            !in_array($t->archetype, ["teacher", "editingteacher"], true)
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        return [
            "protocol" => 1,
            "instance_hash" => $instancehash,
            "policy_hash" => hash("sha256", json_encode([$student, $teacher], JSON_THROW_ON_ERROR)),
        ];
    }
    public static function execute(
        string $instancehash,
        string $policyhash,
        #[\SensitiveParameter] string $payload,
    ): array {
        global $DB, $CFG;
        require_once $CFG->libdir . "/enrollib.php";
        $policy = self::policy($instancehash);
        if (!hash_equals($policy["policy_hash"], $policyhash) || strlen($payload) > 4096) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $p = json_decode($payload, true, 4, JSON_THROW_ON_ERROR);
        if (
            !is_array($p) ||
            count($p) !== 7 ||
            !is_int($p["version"] ?? null) ||
            $p["version"] < 1 ||
            $p["version"] > 2147483646 ||
            !is_bool($p["student"] ?? null) ||
            !is_bool($p["instructor"] ?? null)
        ) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        foreach (["section", "person"] as $key) {
            if (!is_string($p[$key] ?? null) || !preg_match('/^[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $p[$key])) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
        }
        foreach (["course", "user"] as $key) {
            if (
                !is_string($p[$key] ?? null) ||
                (!preg_match('/^[1-9][0-9]{0,18}$/D', $p[$key]) || (string) (int) $p[$key] !== $p[$key])
            ) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
        }
        $course = $DB->get_record("course", ["id" => (int) $p["course"]]);
        $user = $DB->get_record("user", ["id" => (int) $p["user"], "deleted" => 0, "suspended" => 0], "id");
        if (!$course || (int) $course->id === SITEID || !$user || is_siteadmin($user)) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        $context = \context_course::instance($course->id);
        \core_external\external_api::validate_context($context);
        require_capability("enrol/manual:manage", $context);
        require_capability("enrol/manual:enrol", $context);
        require_capability("moodle/role:assign", $context);
        if (
            ($p["student"] && !user_can_assign($context, (int) get_config("local_etsis", "studentrole"))) ||
            ($p["instructor"] && !user_can_assign($context, (int) get_config("local_etsis", "teacherrole")))
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $manual = enrol_get_plugin("manual");
        if (!$manual || !enrol_is_enabled("manual")) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $instance = $DB->get_record("enrol", [
            "courseid" => $course->id,
            "enrol" => "manual",
            "status" => ENROL_INSTANCE_ENABLED,
        ]);
        if (!$instance) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $key = hash("sha256", $p["section"] . ":" . $p["person"]);
        $lock = \core\lock\lock_config::get_lock_factory("local_etsis")->get_lock("roster:" . $key, 5);
        if (!$lock) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $result = [
            "protocol" => 1,
            "instance_hash" => $instancehash,
            "section" => $p["section"],
            "version" => $p["version"],
            "status" => "synchronized",
        ];
        try {
            $old = $DB->get_record("local_etsis_members", ["memberhash" => $key]);
            $hash = hash("sha256", $payload . ":" . $policyhash);
            if (
                $old &&
                ((int) $old->userid !== (int) $user->id ||
                    (int) $old->courseid !== (int) $course->id ||
                    (int) $old->enrolid !== (int) $instance->id)
            ) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
            if ($old && (int) $old->version > $p["version"]) {
                $result["status"] = "superseded";
                return $result;
            }
            if ($old && (int) $old->version === $p["version"]) {
                if (!hash_equals($old->requesthash, $hash)) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
                $result["status"] = "unchanged";
                return $result;
            }
            $enrolled = $DB->get_record("user_enrolments", [
                "enrolid" => $instance->id,
                "userid" => $user->id,
            ]);
            if (!$old && $enrolled) {
                $result["status"] = "externally_managed";
                return $result;
            }
            if (!$old && !$p["student"] && !$p["instructor"]) {
                $result["status"] = "unchanged";
                return $result;
            }
            $transaction = $DB->start_delegated_transaction();
            try {
                if ($old) {
                    foreach (array_unique([(int) $old->studentrole, (int) $old->teacherrole]) as $role) {
                        role_unassign($role, $user->id, $context->id, "enrol_manual", $instance->id);
                    }
                }
                $student = (int) get_config("local_etsis", "studentrole");
                $teacher = (int) get_config("local_etsis", "teacherrole");
                if ($p["student"]) {
                    $manual->enrol_user($instance, $user->id, $student, 0, 0, ENROL_USER_ACTIVE);
                }
                if ($p["instructor"]) {
                    $manual->enrol_user($instance, $user->id, $teacher, 0, 0, ENROL_USER_ACTIVE);
                }
                if (!$p["student"] && !$p["instructor"] && $enrolled) {
                    $manual->update_user_enrol($instance, $user->id, ENROL_USER_SUSPENDED);
                }
                $record = (object) [
                    "memberhash" => $key,
                    "courseid" => $course->id,
                    "userid" => $user->id,
                    "enrolid" => $instance->id,
                    "version" => $p["version"],
                    "requesthash" => $hash,
                    "studentrole" => $student,
                    "teacherrole" => $teacher,
                ];
                if ($old) {
                    $record->id = $old->id;
                    $DB->update_record("local_etsis_members", $record);
                } else {
                    $DB->insert_record("local_etsis_members", $record);
                }
                $transaction->allow_commit();
            } catch (\Throwable $error) {
                $transaction->rollback($error);
            }
            return $result;
        } finally {
            $lock->release();
        }
    }
}
