<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** A receipt and the new user commit together. Never match/adopt an existing account. */
final class account_provisioner
{
    public static function execute(#[\SensitiveParameter] array $data): array
    {
        global $DB, $CFG;
        require_once $CFG->dirroot . "/user/lib.php";
        require_once $CFG->dirroot . "/login/lib.php";
        $policy = account_policy::read($data["instance_hash"]);
        if (
            !hash_equals($policy["policy_hash"], $data["policy_hash"]) ||
            !in_array($data["sign_in"], ["sso", "password_email"], true) ||
            !$policy[$data["sign_in"]]
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        if (
            !preg_match('/^[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $data["operation"]) ||
            !preg_match('/^[a-z0-9][a-z0-9_.@-]{0,99}$/D', $data["username"]) ||
            !validate_email($data["email"]) ||
            strlen($data["email"]) > 100
        ) {
            throw new \moodle_exception("provisioningconflict", "local_etsis");
        }
        foreach (["firstname", "lastname"] as $field) {
            if (
                $data[$field] === "" ||
                \core_text::strlen($data[$field]) > 100 ||
                clean_param($data[$field], PARAM_NOTAGS) !== $data[$field]
            ) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
        }
        $factory = \core\lock\lock_config::get_lock_factory("local_etsis");
        $lock = $factory->get_lock("account-provisioning", 5);
        if (!$lock) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        try {
            $hash = hash("sha256", json_encode($data, JSON_THROW_ON_ERROR));
            $receipt = $DB->get_record("local_etsis_accounts", [
                "operation" => hash("sha256", $data["operation"]),
            ]);
            if ($receipt) {
                if (!hash_equals($receipt->requesthash, $hash) || !$receipt->userid) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
            } else {
                // Refuse email/username conflicts, including accounts created outside this connector.
                if (
                    $DB->record_exists("user", [
                        "username" => $data["username"],
                        "mnethostid" => $CFG->mnet_localhost_id,
                    ]) ||
                    $DB->record_exists_sql(
                        "SELECT 1 FROM {user} WHERE " .
                            $DB->sql_equal("email", ":email", false) .
                            " AND deleted = 0",
                        ["email" => $data["email"]],
                    )
                ) {
                    throw new \moodle_exception("provisioningconflict", "local_etsis");
                }
                $transaction = $DB->start_delegated_transaction();
                try {
                    $user = (object) [
                        "username" => $data["username"],
                        "email" => $data["email"],
                        "firstname" => $data["firstname"],
                        "lastname" => $data["lastname"],
                        "auth" =>
                            $data["sign_in"] === "sso"
                                ? (string) get_config("local_etsis", "ssoauth")
                                : "manual",
                        "password" =>
                            $data["sign_in"] === "sso"
                                ? AUTH_PASSWORD_NOT_CACHED
                                : hash_internal_user_password(bin2hex(random_bytes(48))),
                        "confirmed" => 1,
                        "mnethostid" => $CFG->mnet_localhost_id,
                        "maildisplay" => 0,
                    ];
                    // Never ask an external SSO plugin to update the identity-provider password.
                    $userid = is_callable([\core\user::class, "create_user"])
                        ? \core\user::create_user($user, false, true)
                        : user_create_user($user, false, true);
                    $receipt = (object) [
                        "operation" => hash("sha256", $data["operation"]),
                        "requesthash" => $hash,
                        "userid" => $userid,
                        "signinstatus" => $data["sign_in"] === "sso" ? "sso_ready" : "email_pending",
                        "timecreated" => time(),
                    ];
                    $receipt->id = $DB->insert_record("local_etsis_accounts", $receipt);
                    $transaction->allow_commit();
                } catch (\Throwable $error) {
                    $transaction->rollback($error);
                }
            }
            $user = $DB->get_record("user", ["id" => $receipt->userid, "deleted" => 0, "suspended" => 0]);
            if (!$user || is_siteadmin($user)) {
                throw new \moodle_exception("provisioningconflict", "local_etsis");
            }
            if ($receipt->signinstatus === "email_pending") {
                // Commit an attempt marker BEFORE sending. A crash can require review, never a blind resend.
                $DB->set_field("local_etsis_accounts", "signinstatus", "email_attempting", [
                    "id" => $receipt->id,
                ]);
                $status = "email_review_required";
                try {
                    if (
                        $user->auth === "manual" &&
                        $user->email === $data["email"] &&
                        has_capability(
                            "moodle/user:changeownpassword",
                            \context_system::instance(),
                            $user->id,
                        ) &&
                        !$DB->record_exists("user_password_resets", ["userid" => $user->id])
                    ) {
                        $reset = core_login_generate_password_reset($user);
                        if (send_password_change_confirmation_email($user, $reset)) {
                            $status = "email_sent";
                        }
                    }
                } catch (\Throwable) {
                    /* Keep private mail/transport details out of REST errors. */
                }
                $DB->set_field("local_etsis_accounts", "signinstatus", $status, ["id" => $receipt->id]);
                $receipt->signinstatus = $status;
            } elseif ($receipt->signinstatus === "email_attempting") {
                $receipt->signinstatus = "email_review_required";
            }
            return [
                "protocol" => 1,
                "instance_hash" => $data["instance_hash"],
                "operation" => $data["operation"],
                "user_id" => (string) $receipt->userid,
                "sign_in_status" => $receipt->signinstatus,
            ];
        } finally {
            $lock->release();
        }
    }
}
