<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
/** Dedicated, TLS-verified, nonce-bound server channel. No cookies or REST tokens. */
final class session_channel
{
    public function __construct(private ?\Closure $transport = null) {}
    public static function base_url(): string
    {
        $url = (string) get_config("local_etsis", "sisurl");
        $parts = parse_url($url);
        if (
            strlen($url) > 2048 ||
            preg_match('/[\x00-\x20\x7f\\\\]/', $url) ||
            !$parts ||
            ($parts["scheme"] ?? "") !== "https" ||
            empty($parts["host"]) ||
            isset($parts["user"]) ||
            isset($parts["pass"]) ||
            isset($parts["query"]) ||
            isset($parts["fragment"])
        ) {
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
        foreach (explode("/", $parts["path"] ?? "") as $segment) {
            if (in_array(rawurldecode($segment), [".", ".."], true)) {
                throw new \moodle_exception("launchunavailable", "local_etsis");
            }
        }
        $port = isset($parts["port"]) && $parts["port"] !== 443 ? ":" . $parts["port"] : "";
        return "https://" . strtolower($parts["host"]) . $port . rtrim($parts["path"] ?? "", "/");
    }
    /** Strict Origin binding prevents login CSRF with an attacker's valid ticket. */
    public static function permits_origin(string $origin): bool
    {
        $base = parse_url(self::base_url());
        $expected = "https://" . $base["host"] . (isset($base["port"]) ? ":" . $base["port"] : "");
        return $origin !== "" && hash_equals($expected, $origin);
    }
    public function send(#[\SensitiveParameter] array $data): array
    {
        global $CFG;
        $secret = $CFG->local_etsis_launch_secret ?? "";
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            (int) get_config("local_etsis", "launch") !== 1 ||
            !is_string($secret) ||
            !preg_match('/^[a-f0-9]{64}$/D', $secret)
        ) {
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
        $data["instance_hash"] = hash("sha256", instance_identity::read());
        $body = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        $time = (string) time();
        $nonce = bin2hex(random_bytes(32));
        $key = hex2bin($secret);
        $signature = hash_hmac("sha256", "etsis-moodle/v1\nrequest\n$time\n$nonce\n$body", $key);
        $headers = [
            "Content-Type: application/json",
            "X-Etsis-Time: " . $time,
            "X-Etsis-Nonce: " . $nonce,
            "X-Etsis-Signature: " . $signature,
        ];
        $url = self::base_url() . "/sis/moodle/session-channel/";
        try {
            [$status, $reply, $signature] =
                $this->transport !== null
                    ? ($this->transport)($url, $body, $headers)
                    : $this->post($url, $body, $headers);
            if (
                $status !== 200 ||
                !is_string($reply) ||
                strlen($reply) > 4096 ||
                !is_string($signature) ||
                !preg_match('/^[a-f0-9]{64}$/D', $signature) ||
                !hash_equals(
                    hash_hmac("sha256", "etsis-moodle/v1\nresponse\n$time\n$nonce\n$reply", $key),
                    $signature,
                )
            ) {
                throw new \RuntimeException();
            }
            $result = json_decode($reply, true, 8, JSON_THROW_ON_ERROR);
            if (
                !is_array($result) ||
                ($result["active"] ?? null) !== true ||
                !is_string($result["grant_id"] ?? null) ||
                !preg_match('/^[0-9A-HJKMNP-TV-Z]{26}$/D', $result["grant_id"]) ||
                !is_string($result["moodle_user_id"] ?? null) ||
                !preg_match('/^[1-9][0-9]{0,18}$/D', $result["moodle_user_id"]) ||
                !is_int($result["expires_at"] ?? null) ||
                $result["expires_at"] <= time()
            ) {
                throw new \RuntimeException();
            }
            return $result;
        } catch (\Throwable) {
            // Never include network responses, posted credentials or exception chains in Moodle errors.
            throw new \moodle_exception("launchunavailable", "local_etsis");
        }
    }
    private function post(string $url, #[\SensitiveParameter] string $body, array $headers): array
    {
        global $CFG;
        $handle = curl_init($url);
        $response = "";
        $signature = "";
        $size = 0;
        try {
            $options = [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_CONNECTTIMEOUT => 1,
                CURLOPT_TIMEOUT => 3,
                CURLOPT_NOSIGNAL => true,
                CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use (&$response): int {
                    if (strlen($response) + strlen($chunk) > 4096) {
                        return 0;
                    }
                    $response .= $chunk;
                    return strlen($chunk);
                },
                CURLOPT_HEADERFUNCTION => static function ($handle, string $line) use (
                    &$signature,
                    &$size,
                ): int {
                    $size += strlen($line);
                    if ($size > 8192) {
                        return 0;
                    }
                    if (stripos($line, "X-Etsis-Signature:") === 0) {
                        $signature = trim(substr($line, strlen("X-Etsis-Signature:")));
                    }
                    return strlen($line);
                },
            ];
            if (!empty($CFG->local_etsis_launch_ca_file)) {
                $options[CURLOPT_CAINFO] = $CFG->local_etsis_launch_ca_file;
            }
            curl_setopt_array($handle, $options);
            if (curl_exec($handle) === false) {
                throw new \RuntimeException();
            }
            return [(int) curl_getinfo($handle, CURLINFO_HTTP_CODE), $response, $signature];
        } finally {
            curl_close($handle);
        }
    }
}
