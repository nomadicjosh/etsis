<?php
// SPDX-License-Identifier: GPL-3.0-or-later

namespace local_etsis\local;

defined("MOODLE_INTERNAL") || die();

/** Installation-owned opaque identity. No person, course, account or credential data. */
final class instance_identity
{
    public static function initialize(): void
    {
        $existing = get_config("local_etsis", "instanceid");
        if ($existing !== false) {
            self::read();
            return;
        }
        set_config("instanceid", bin2hex(random_bytes(16)), "local_etsis");
    }
    public static function read(): string
    {
        $id = get_config("local_etsis", "instanceid");
        if (!is_string($id) || preg_match('/^[a-f0-9]{32}$/D', $id) !== 1) {
            throw new \moodle_exception("identityunavailable", "local_etsis");
        }
        return $id;
    }
}
