<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();

/** Show fixed local guidance instead of a generated, nonexistent Moodle Docs error page. */
final class launch_error
{
    public static function reason(string $code): string
    {
        return in_array($code, ["launchsiteadmin", "launchaccountswitch"], true)
            ? $code
            : "launchunavailable";
    }

    public static function display(string $code): void
    {
        global $PAGE, $OUTPUT;
        $PAGE->set_url(new \moodle_url("/local/etsis/launch.php"));
        $PAGE->set_context(\context_system::instance());
        $PAGE->set_pagelayout("login");
        $title = get_string("launcherrortitle", "local_etsis");
        $PAGE->set_title($title);
        $PAGE->set_heading($title);
        $header = $OUTPUT->header();
        http_response_code(403);
        header("Cache-Control: private, no-store, max-age=0");
        header("Referrer-Policy: no-referrer");
        echo $header;
        echo $OUTPUT->heading($title);
        echo \html_writer::tag("p", s(get_string(self::reason($code), "local_etsis")));
        echo \html_writer::tag(
            "p",
            s(
                get_string(
                    self::reason($code) === "launchsiteadmin" ? "launchadminhelp" : "launchhelp",
                    "local_etsis",
                ),
            ),
        );
        echo $OUTPUT->single_button(
            new \moodle_url("/login/index.php"),
            get_string("launchmoodlesignin", "local_etsis"),
            "get",
        );
        try {
            $url = new \moodle_url(session_channel::base_url() . "/portal/moodle/");
        } catch (\Throwable) {
            $url = null;
        }
        if ($url !== null) {
            echo \html_writer::tag(
                "p",
                \html_writer::link($url, get_string("launchbacktocampus", "local_etsis")),
            );
        }
        echo $OUTPUT->footer();
    }
}
