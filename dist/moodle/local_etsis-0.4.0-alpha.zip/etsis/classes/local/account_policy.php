<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\local;
defined("MOODLE_INTERNAL") || die();
final class account_policy
{
    public static function read(string $instancehash): array
    {
        global $CFG;
        require_once $CFG->libdir . "/authlib.php";
        $context = \context_system::instance();
        \core_external\external_api::validate_context($context);
        require_capability("local/etsis:provisionaccounts", $context);
        require_capability("moodle/user:create", $context);
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            (int) get_config("local_etsis", "provisioning") !== 1
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        if (!hash_equals(hash("sha256", instance_identity::read()), $instancehash)) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $sso = (string) get_config("local_etsis", "ssoauth");
        $email = (int) get_config("local_etsis", "passwordemail") === 1;
        if (
            $sso !== "" &&
            (!preg_match('/^[a-z][a-z0-9_]*$/D', $sso) ||
                !is_enabled_auth($sso) ||
                in_array($sso, ["manual", "email", "nologin", "none"], true) ||
                get_auth_plugin($sso)->is_internal())
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        if ($email && (!is_enabled_auth("manual") || !get_auth_plugin("manual")->can_reset_password())) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $hash = hash(
            "sha256",
            json_encode(
                [$sso, $email, (string) get_config("local_etsis", "policyrevision")],
                JSON_THROW_ON_ERROR,
            ),
        );
        return [
            "protocol" => 1,
            "instance_hash" => $instancehash,
            "policy_hash" => $hash,
            "sso" => $sso !== "",
            "password_email" => $email,
        ];
    }
}
