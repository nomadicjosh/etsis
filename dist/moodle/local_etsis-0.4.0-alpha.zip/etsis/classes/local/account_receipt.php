<?php
// SPDX-License-Identifier: GPL-3.0-or-later

namespace local_etsis\local;

defined("MOODLE_INTERNAL") || die();

/** Read an existing creation receipt; no locks, account writes or email effects. */
final class account_receipt
{
    public static function read(string $instancehash, string $operation, string $requesthash): array
    {
        global $DB;
        $context = \context_system::instance();
        \core_external\external_api::validate_context($context);
        require_capability("local/etsis:provisionaccounts", $context);
        require_capability("local/etsis:viewinstance", $context);
        if (
            (int) get_config("local_etsis", "enabled") !== 1 ||
            !hash_equals(hash("sha256", instance_identity::read()), $instancehash) ||
            preg_match('/^[0-7][0-9A-HJKMNP-TV-Z]{25}$/D', $operation) !== 1 ||
            preg_match('/^[a-f0-9]{64}$/D', $requesthash) !== 1
        ) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $result = [
            "protocol" => 1,
            "instance_hash" => $instancehash,
            "operation" => $operation,
            "request_hash" => $requesthash,
            "status" => "not_observed",
            "user_id" => "0",
            "sign_in_status" => "unknown",
        ];
        $receipt = $DB->get_record("local_etsis_accounts", ["operation" => hash("sha256", $operation)]);
        if (!$receipt) {
            return $result;
        }
        if (!hash_equals($receipt->requesthash, $requesthash)) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
        $result["status"] = "restricted";
        if (!$receipt->userid) {
            return $result;
        }
        $user = $DB->get_record("user", ["id" => $receipt->userid, "deleted" => 0, "suspended" => 0], "id");
        if (!$user || is_siteadmin($user)) {
            return $result;
        }
        $status = match ($receipt->signinstatus) {
            "sso_ready", "email_sent", "email_review_required" => $receipt->signinstatus,
            "email_pending", "email_attempting" => "email_review_required",
            default => throw new \moodle_exception("provisioningunavailable", "local_etsis"),
        };
        $result["status"] = "recorded";
        $result["user_id"] = (string) $receipt->userid;
        $result["sign_in_status"] = $status;
        return $result;
    }
}
