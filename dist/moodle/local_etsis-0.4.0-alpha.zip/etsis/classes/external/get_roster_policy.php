<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\external;
use core_external\{external_api, external_function_parameters, external_single_structure, external_value};
defined("MOODLE_INTERNAL") || die();
final class get_roster_policy extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation"),
        ]);
    }
    public static function execute(string $instance_hash): array
    {
        $p = self::validate_parameters(self::execute_parameters(), compact("instance_hash"));
        try {
            return \local_etsis\local\roster_sync::policy($p["instance_hash"]);
        } catch (\Throwable) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Installation hash"),
            "policy_hash" => new external_value(PARAM_ALPHANUM, "Approved course-role policy"),
        ]);
    }
}
