<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\external;
use core_external\{external_api, external_function_parameters, external_single_structure, external_value};
defined("MOODLE_INTERNAL") || die();
final class get_account_policy extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation SHA-256"),
        ]);
    }
    public static function execute(string $instance_hash): array
    {
        self::validate_parameters(self::execute_parameters(), ["instance_hash" => $instance_hash]);
        return \local_etsis\local\account_policy::read($instance_hash);
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Installation hash"),
            "policy_hash" => new external_value(PARAM_ALPHANUM, "Authentication policy hash"),
            "sso" => new external_value(PARAM_BOOL, "Institutional SSO supported"),
            "password_email" => new external_value(PARAM_BOOL, "Password-setup email supported"),
        ]);
    }
}
