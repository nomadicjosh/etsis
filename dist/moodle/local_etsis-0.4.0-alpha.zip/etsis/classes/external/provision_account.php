<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\external;
use core_external\{external_api, external_function_parameters, external_single_structure, external_value};
defined("MOODLE_INTERNAL") || die();
final class provision_account extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        $fields = [];
        foreach (
            [
                "instance_hash",
                "policy_hash",
                "operation",
                "username",
                "email",
                "firstname",
                "lastname",
                "sign_in",
            ]
            as $field
        ) {
            $fields[$field] = new external_value(
                PARAM_RAW,
                "Reviewed account attribute or opaque operation reference",
            );
        }
        return new external_function_parameters($fields);
    }
    public static function execute(
        string $instance_hash,
        string $policy_hash,
        string $operation,
        #[\SensitiveParameter] string $username,
        #[\SensitiveParameter] string $email,
        #[\SensitiveParameter] string $firstname,
        #[\SensitiveParameter] string $lastname,
        string $sign_in,
    ): array {
        $data = self::validate_parameters(
            self::execute_parameters(),
            compact(
                "instance_hash",
                "policy_hash",
                "operation",
                "username",
                "email",
                "firstname",
                "lastname",
                "sign_in",
            ),
        );
        // Do not attach native database, user or mail exceptions to the returned error.
        try {
            return \local_etsis\local\account_provisioner::execute($data);
        } catch (\Throwable) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation hash"),
            "operation" => new external_value(PARAM_ALPHANUM, "Original creation operation"),
            "user_id" => new external_value(PARAM_ALPHANUM, "Created Moodle ID"),
            "sign_in_status" => new external_value(PARAM_ALPHANUMEXT, "Sign-in setup result"),
        ]);
    }
}
