<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\external;
use core_external\{external_api, external_function_parameters, external_single_structure, external_value};
defined("MOODLE_INTERNAL") || die();
final class sync_roster_member extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation"),
            "policy_hash" => new external_value(PARAM_ALPHANUM, "Approved course-role policy"),
            "payload" => new external_value(PARAM_RAW, "Minimized course-access references"),
        ]);
    }
    public static function execute(
        string $instance_hash,
        string $policy_hash,
        #[\SensitiveParameter] string $payload,
    ): array {
        $p = self::validate_parameters(
            self::execute_parameters(),
            compact("instance_hash", "policy_hash", "payload"),
        );
        try {
            return \local_etsis\local\roster_sync::execute(
                $p["instance_hash"],
                $p["policy_hash"],
                $p["payload"],
            );
        } catch (\Throwable) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Installation hash"),
            "section" => new external_value(PARAM_ALPHANUM, "Section reference"),
            "version" => new external_value(PARAM_INT, "Access reconciliation fence"),
            "status" => new external_value(PARAM_ALPHANUMEXT, "Fixed result"),
        ]);
    }
}
