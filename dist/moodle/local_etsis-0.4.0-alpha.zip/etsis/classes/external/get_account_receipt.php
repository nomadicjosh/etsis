<?php
// SPDX-License-Identifier: GPL-3.0-or-later

namespace local_etsis\external;

use core_external\{external_api, external_function_parameters, external_single_structure, external_value};

defined("MOODLE_INTERNAL") || die();

final class get_account_receipt extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation hash"),
            "operation" => new external_value(PARAM_ALPHANUM, "Original account-creation operation"),
            "request_hash" => new external_value(PARAM_ALPHANUM, "Original exact request digest"),
        ]);
    }

    public static function execute(string $instance_hash, string $operation, string $request_hash): array
    {
        $data = self::validate_parameters(
            self::execute_parameters(),
            compact("instance_hash", "operation", "request_hash"),
        );
        try {
            return \local_etsis\local\account_receipt::read(
                $data["instance_hash"],
                $data["operation"],
                $data["request_hash"],
            );
        } catch (\Throwable) {
            throw new \moodle_exception("provisioningunavailable", "local_etsis");
        }
    }

    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            "protocol" => new external_value(PARAM_INT, "Protocol"),
            "instance_hash" => new external_value(PARAM_ALPHANUM, "Approved installation hash"),
            "operation" => new external_value(PARAM_ALPHANUM, "Original creation operation"),
            "request_hash" => new external_value(PARAM_ALPHANUM, "Original request digest"),
            "status" => new external_value(PARAM_ALPHANUMEXT, "Receipt observation status"),
            "user_id" => new external_value(
                PARAM_ALPHANUM,
                "Created account reference, or zero if unavailable",
            ),
            "sign_in_status" => new external_value(PARAM_ALPHANUMEXT, "Recorded sign-in setup result"),
        ]);
    }
}
