<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis\privacy;
use core_privacy\local\metadata\collection;
use core_privacy\local\request\{approved_contextlist, approved_userlist, contextlist, userlist, writer};
defined("MOODLE_INTERNAL") || die();
final class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider
{
    public static function get_metadata(collection $collection): collection
    {
        $collection->add_external_location_link(
            "etsis",
            [
                "grant_id" => "privacy:metadata:grant",
                "moodle_user_id" => "privacy:metadata:userid",
            ],
            "privacy:metadata:sessionchannel",
        );
        return $collection->add_database_table(
            "local_etsis_accounts",
            [
                "userid" => "privacy:metadata:userid",
                "operation" => "privacy:metadata:operation",
                "requesthash" => "privacy:metadata:requesthash",
                "signinstatus" => "privacy:metadata:signinstatus",
                "timecreated" => "privacy:metadata:timecreated",
            ],
            "privacy:metadata:accounts",
        );
    }
    public static function get_contexts_for_userid(int $userid): contextlist
    {
        $list = new contextlist();
        $list->add_from_sql(
            "SELECT c.id FROM {context} c WHERE c.contextlevel = :level AND EXISTS (SELECT 1 FROM {local_etsis_accounts} a WHERE a.userid = :userid)",
            ["level" => CONTEXT_SYSTEM, "userid" => $userid],
        );
        return $list;
    }
    public static function get_users_in_context(userlist $userlist): void
    {
        if ($userlist->get_context()->contextlevel !== CONTEXT_SYSTEM) {
            return;
        }
        $userlist->add_from_sql("userid", "SELECT userid FROM {local_etsis_accounts} WHERE userid > 0", []);
    }
    public static function export_user_data(approved_contextlist $contextlist): void
    {
        global $DB;
        $context = \context_system::instance();
        if (!in_array($context->id, $contextlist->get_contextids())) {
            return;
        }
        $records = $DB->get_records("local_etsis_accounts", ["userid" => $contextlist->get_user()->id]);
        foreach ($records as $record) {
            writer::with_context($context)->export_data(
                [get_string("pluginname", "local_etsis"), (string) $record->id],
                (object) [
                    "operation" => $record->operation,
                    "requesthash" => $record->requesthash,
                    "signinstatus" => $record->signinstatus,
                    "timecreated" => $record->timecreated,
                ],
            );
        }
    }
    public static function delete_data_for_all_users_in_context(\context $context): void
    {
        if ($context->contextlevel === CONTEXT_SYSTEM) {
            self::anonymize(null);
        }
    }
    public static function delete_data_for_user(approved_contextlist $contextlist): void
    {
        if (in_array(\context_system::instance()->id, $contextlist->get_contextids())) {
            self::anonymize([$contextlist->get_user()->id]);
        }
    }
    public static function delete_data_for_users(approved_userlist $userlist): void
    {
        if ($userlist->get_context()->contextlevel === CONTEXT_SYSTEM) {
            self::anonymize($userlist->get_userids());
        }
    }
    private static function anonymize(?array $users): void
    {
        global $DB;
        if ($users === []) {
            return;
        }
        $where = "userid > 0";
        $params = [];
        if ($users !== null) {
            [$in, $params] = $DB->get_in_or_equal($users, SQL_PARAMS_NAMED);
            $where = "userid " . $in;
        }
        // Keep an opaque denial tombstone so privacy erasure cannot turn a retry into new account creation.
        $DB->execute(
            "UPDATE {local_etsis_accounts} SET userid = 0, requesthash = :emptyhash, signinstatus = :status, timecreated = 0 WHERE $where",
            $params + ["emptyhash" => str_repeat("0", 64), "status" => "erased"],
        );
    }
}
