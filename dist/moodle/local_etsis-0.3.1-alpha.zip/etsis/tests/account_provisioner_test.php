<?php
// SPDX-License-Identifier: GPL-3.0-or-later
namespace local_etsis;
use local_etsis\local\{account_policy, account_provisioner, instance_identity};
defined("MOODLE_INTERNAL") || die();
/** Execute only in Moodle's separately configured PHPUnit database. */
final class account_provisioner_test extends \advanced_testcase
{
    private function setup_policy(): array
    {
        $this->resetAfterTest();
        $this->setAdminUser();
        instance_identity::initialize();
        set_config("enabled", 1, "local_etsis");
        set_config("provisioning", 1, "local_etsis");
        set_config("passwordemail", 1, "local_etsis");
        set_config("ssoauth", "", "local_etsis");
        set_config("auth", "manual");
        $instance = hash("sha256", instance_identity::read());
        $policy = account_policy::read($instance);
        return [
            "instance_hash" => $instance,
            "policy_hash" => $policy["policy_hash"],
            "operation" => "01KAT5HZXS0000000000000001",
            "username" => "alex_example",
            "email" => "fictional@example.invalid",
            "firstname" => "Alex",
            "lastname" => "Example",
            "sign_in" => "password_email",
        ];
    }
    public function test_retry_returns_original_account_and_sends_one_setup_link(): void
    {
        global $DB;
        $data = $this->setup_policy();
        $sink = $this->redirectEmails();
        $first = account_provisioner::execute($data);
        $second = account_provisioner::execute($data);
        $this->assertSame($first, $second);
        $this->assertSame("email_sent", $first["sign_in_status"]);
        $this->assertSame(1, $DB->count_records("local_etsis_accounts"));
        $messages = $sink->get_messages();
        $this->assertCount(1, $messages);
        $this->assertStringContainsString("/login/forgot_password.php?token=", $messages[0]->body);
        $user = $DB->get_record("user", ["id" => (int) $first["user_id"]], "*", MUST_EXIST);
        $this->assertSame("manual", $user->auth);
        $this->assertFalse(is_siteadmin($user));
        $this->assertSame(0, $DB->count_records("role_assignments", ["userid" => $user->id]));
    }
    public function test_existing_account_is_not_adopted(): void
    {
        global $DB;
        $data = $this->setup_policy();
        $this->getDataGenerator()->create_user(["username" => $data["username"]]);
        try {
            account_provisioner::execute($data);
            $this->fail("Existing account was adopted.");
        } catch (\moodle_exception) {
            $this->assertSame(0, $DB->count_records("local_etsis_accounts"));
        }
    }
    public function test_changed_retry_and_policy_are_refused_without_second_email(): void
    {
        global $DB;
        $data = $this->setup_policy();
        $sink = $this->redirectEmails();
        account_provisioner::execute($data);
        $data["email"] = "another@example.invalid";
        try {
            account_provisioner::execute($data);
            $this->fail("Changed request accepted.");
        } catch (\moodle_exception) {
        }
        $this->assertCount(1, $sink->get_messages());
        $this->assertSame(1, $DB->count_records("local_etsis_accounts"));
        set_config("policyrevision", "2", "local_etsis");
        $this->expectException(\moodle_exception::class);
        account_provisioner::execute($data);
    }
    public function test_uncertain_email_attempt_is_not_resent(): void
    {
        global $DB;
        $data = $this->setup_policy();
        $sink = $this->redirectEmails();
        account_provisioner::execute($data);
        $DB->set_field("local_etsis_accounts", "signinstatus", "email_attempting", []);
        $result = account_provisioner::execute($data);
        $this->assertSame("email_review_required", $result["sign_in_status"]);
        $this->assertCount(1, $sink->get_messages());
    }
    public function test_sso_creation_sends_no_email_or_identity_provider_password_update(): void
    {
        global $DB;
        $data = $this->setup_policy();
        set_config("auth", "oauth2");
        set_config("ssoauth", "oauth2", "local_etsis");
        $data["policy_hash"] = account_policy::read($data["instance_hash"])["policy_hash"];
        $data["sign_in"] = "sso";
        $sink = $this->redirectEmails();
        $result = account_provisioner::execute($data);
        $user = $DB->get_record("user", ["id" => (int) $result["user_id"]], "*", MUST_EXIST);
        $this->assertSame("oauth2", $user->auth);
        $this->assertSame(AUTH_PASSWORD_NOT_CACHED, $user->password);
        $this->assertSame("sso_ready", $result["sign_in_status"]);
        $this->assertCount(0, $sink->get_messages());
    }
    public function test_privacy_erasure_keeps_only_a_denial_tombstone(): void
    {
        global $DB;
        $data = $this->setup_policy();
        $this->redirectEmails();
        $result = account_provisioner::execute($data);
        $user = $DB->get_record("user", ["id" => (int) $result["user_id"]], "*", MUST_EXIST);
        $contexts = new \core_privacy\local\request\approved_contextlist($user, "local_etsis", [
            \context_system::instance()->id,
        ]);
        \local_etsis\privacy\provider::delete_data_for_user($contexts);
        $receipt = $DB->get_record(
            "local_etsis_accounts",
            ["operation" => hash("sha256", $data["operation"])],
            "*",
            MUST_EXIST,
        );
        $this->assertSame(0, (int) $receipt->userid);
        $this->assertSame(str_repeat("0", 64), $receipt->requesthash);
        $this->expectException(\moodle_exception::class);
        account_provisioner::execute($data);
    }
    public function test_ordinary_user_cannot_provision(): void
    {
        $data = $this->setup_policy();
        $this->setUser($this->getDataGenerator()->create_user());
        $this->expectException(\required_capability_exception::class);
        account_provisioner::execute($data);
    }
}
