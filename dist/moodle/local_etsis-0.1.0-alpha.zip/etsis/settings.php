<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_etsis', get_string('pluginname', 'local_etsis'));
    $ADMIN->add('localplugins', $settings);
    if ($ADMIN->fulltree) {
        $settings->add(new admin_setting_configcheckbox(
            'local_etsis/enabled',
            get_string('enabled', 'local_etsis'),
            get_string('enabled_desc', 'local_etsis'),
            0,
        ));
    }
}
