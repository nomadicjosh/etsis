# etSIS connector for Moodle

Component: `local_etsis` · Release: **0.1.0-alpha** · License: **GPL-3.0-or-later**

This first connector release provides one restricted, read-only web-service function: `local_etsis_get_instance_info`. It returns protocol version 1 and a random installation identifier. It does not provide SSO, create accounts, synchronize courses/enrollments or import grades. No personal data is stored by this plugin.

## Install

The plugin declares Moodle **4.5 or later** as its minimum. This alpha still requires acceptance testing on each supported Moodle branch before institutional deployment. Follow your institution's backup and change-review procedure.

1. Download `local_etsis-0.1.0-alpha.zip` from the etSIS distributor. Compare its SHA-256 with the independently obtained release checksum.
2. Sign in to Moodle as a site administrator. Open **Site administration → Plugins → Install plugins**, upload the ZIP and follow Moodle's validation and installation screens. The package contains the `etsis/` directory and declares the `local_etsis` component.
3. If ZIP installation is unavailable, extract the `etsis` directory into your Moodle **code root's** `local/` directory, then visit **Site administration → Notifications**. Some installations have a `public/` code root; follow your installation's layout.
4. The plugin and its predefined web service install **disabled**. Installation creates only a random installation ID in plugin configuration. It creates no accounts, tokens, role grants or academic tables.

## Enable verification explicitly

1. Under **Site administration → Plugins → Local plugins → etSIS connector**, enable installation verification.
2. Enable Moodle web services and the REST protocol if institutionally approved.
3. Give a dedicated integration account a narrowly scoped system role granting **local/etsis:viewinstance**. This plugin grants the capability to no role automatically. Do not use an administrator token.
4. Under **Server → Web services → External services**, enable **etSIS instance verification** and add that account as an authorized user. The service is restricted to authorized users and contains only `core_webservice_get_site_info` and `local_etsis_get_instance_info`. Keep the account subject to Moodle's web-service/token restrictions; configure the required REST and token permissions according to institutional policy.
5. Create a token for that account and that restricted service. Supply it securely through etSIS deployment settings (`SIS_MOODLE_TOKEN`), with the canonical HTTPS `SIS_MOODLE_URL` and `SIS_MOODLE_ENABLED=true`. Never put the token in a download, screenshot, command argument or browser storage.
6. From etSIS run `ddev codex sis:moodle:instance` (or `codex` with its configured PHP interpreter). It reports a SHA-256 installation fingerprint, without saving a binding or requesting student records.

Existing custom services may add the function after review instead of using the predefined service. Do not broaden a token just to make every etSIS capability flag appear available. A successful connection check can work without this plugin; instance verification requires it.

## Identity, recovery and disabling

The ID is generated only during initial installation. Reads never generate or repair an ID. A missing or malformed ID blocks verification; investigate configuration/backup recovery instead of silently replacing it. Routine upgrades retain the ID. Restore the same ID when recovering the same installation.

A full database clone carries the same ID. This release does **not** detect clones, provide identity rotation or establish persistent etSIS mappings. Keep clones disconnected from the integration and review their identity/configuration before enabling them as a separate installation. Uninstalling/reinstalling can change the identity and must not be used as a casual repair procedure.

Disable verification in plugin settings, disable its service or revoke its token to stop access. Disable the etSIS setting separately to stop outgoing requests. Nothing in this release changes student academic facts.

## Developer checks

Native Moodle tests are in `tests/instance_identity_test.php`. Run them only in Moodle's separately configured PHPUnit environment, using Moodle's documented test database, never the institutional application database. The etSIS source also includes gateway/console tests and reproducible package tests. Native Moodle test execution and institutional installation acceptance are separate checks.

Sources: [Installing plugins](https://docs.moodle.org/en/Installing_plugins), [external functions](https://moodledev.io/docs/5.3/apis/subsystems/external/functions), [plugin files](https://moodledev.io/docs/5.3/apis/commonfiles).
