<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'etSIS connector';
$string['enabled'] = 'Enable instance verification';
$string['enabled_desc'] = 'Allow authorized integration service users to read this installation identity. This does not enable SSO or synchronize any records.';
$string['etsis:viewinstance'] = 'Read the etSIS installation verification identity';
$string['identityunavailable'] = 'The installation identity is unavailable. Ask the site administrator to review plugin installation; no new identity has been generated.';
$string['integrationdisabled'] = 'etSIS instance verification is disabled.';
$string['privacy:metadata'] = 'This plugin stores only an installation identity and an enablement setting; it does not store personal data.';
