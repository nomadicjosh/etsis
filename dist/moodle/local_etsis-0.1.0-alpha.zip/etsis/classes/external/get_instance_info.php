<?php
// SPDX-License-Identifier: GPL-3.0-or-later

namespace local_etsis\external;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_single_structure;
use core_external\external_value;

// The service is token-protected and additionally requires an explicit system capability.
defined('MOODLE_INTERNAL') || die();

final class get_instance_info extends external_api
{
    public static function execute_parameters(): external_function_parameters
    {
        return new external_function_parameters([]);
    }
    public static function execute(): array
    {
        self::validate_parameters(self::execute_parameters(), []);
        $context = \context_system::instance();
        self::validate_context($context);
        require_capability('local/etsis:viewinstance', $context);
        if ((int) get_config('local_etsis', 'enabled') !== 1) {
            throw new \moodle_exception('integrationdisabled', 'local_etsis');
        }
        return ['protocol' => 1, 'instance_id' => \local_etsis\local\instance_identity::read()];
    }
    public static function execute_returns(): external_single_structure
    {
        return new external_single_structure([
            'protocol' => new external_value(PARAM_INT, 'Instance identity protocol version'),
            'instance_id' => new external_value(PARAM_ALPHANUM, 'Opaque installation identity'),
        ]);
    }
}
