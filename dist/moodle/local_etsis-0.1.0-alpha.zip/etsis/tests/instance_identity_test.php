<?php
// SPDX-License-Identifier: GPL-3.0-or-later

namespace local_etsis;

use local_etsis\external\get_instance_info;
use local_etsis\local\instance_identity;

defined('MOODLE_INTERNAL') || die();

/** Run only with Moodle's dedicated PHPUnit database. */
final class instance_identity_test extends \advanced_testcase
{
    public function test_initialization_preserves_existing_identity(): void
    {
        $this->resetAfterTest();
        unset_config('instanceid', 'local_etsis');
        instance_identity::initialize();
        $first = instance_identity::read();
        $this->assertMatchesRegularExpression('/^[a-f0-9]{32}$/D', $first);
        instance_identity::initialize();
        $this->assertSame($first, instance_identity::read());
    }

    public function test_missing_identity_is_not_recreated_on_read(): void
    {
        $this->resetAfterTest();
        unset_config('instanceid', 'local_etsis');
        try {
            instance_identity::read();
            $this->fail('Missing identity was accepted.');
        } catch (\moodle_exception $error) {
            $this->assertSame('identityunavailable', $error->errorcode);
            $this->assertFalse(get_config('local_etsis', 'instanceid'));
        }
    }

    public function test_disabled_verification_refuses_even_an_administrator(): void
    {
        $this->resetAfterTest();
        $this->setAdminUser();
        set_config('enabled', 0, 'local_etsis');
        $this->expectException(\moodle_exception::class);
        get_instance_info::execute();
    }

    public function test_ordinary_account_cannot_read_enabled_identity(): void
    {
        $this->resetAfterTest();
        $this->setUser($this->getDataGenerator()->create_user());
        set_config('enabled', 1, 'local_etsis');
        $this->expectException(\required_capability_exception::class);
        get_instance_info::execute();
    }

    public function test_enabled_authorized_read_returns_only_protocol_and_identity(): void
    {
        $this->resetAfterTest();
        $this->setAdminUser();
        instance_identity::initialize();
        set_config('enabled', 1, 'local_etsis');
        $result = get_instance_info::execute();
        $this->assertSame(['protocol' => 1, 'instance_id' => instance_identity::read()], $result);
        $this->assertSame($result, get_instance_info::execute());
    }
}
