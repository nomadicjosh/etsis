<?php
// SPDX-License-Identifier: GPL-3.0-or-later

defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_etsis_get_instance_info' => [
        'classname' => 'local_etsis\external\get_instance_info',
        'methodname' => 'execute',
        'description' => 'Read the installation identity without personal or academic data.',
        'type' => 'read',
        'ajax' => false,
        'loginrequired' => true,
        'capabilities' => 'local/etsis:viewinstance',
    ],
];
$services = [
    'etSIS instance verification' => [
        'functions' => ['core_webservice_get_site_info', 'local_etsis_get_instance_info'],
        'restrictedusers' => 1,
        'enabled' => 0,
        'shortname' => 'local_etsis_identity',
    ],
];
